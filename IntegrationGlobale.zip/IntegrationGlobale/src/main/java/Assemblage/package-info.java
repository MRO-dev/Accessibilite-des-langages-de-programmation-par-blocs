/**
 * Package contenant la m�thode principale de l'ensemble du projet qui r�alise l'int�gration entre le Package GenerationJSON et le 
 * package ReconnaissanceAlgorithme
 * @author Jean-Baptiste Marco
 */

package Assemblage;