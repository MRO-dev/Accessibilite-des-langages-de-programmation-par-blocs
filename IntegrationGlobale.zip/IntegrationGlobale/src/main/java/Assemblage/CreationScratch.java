package Assemblage;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Writer;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.node.ObjectNode;

import GenerationJSON.Outils.CodesSemantique;
import GenerationJSON.Outils.ETypeBlocks;
import GenerationJSON.Outils.Entite;
import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.ScratchBlocks.Message;
import GenerationJSON.ScratchBlocks.Variable;
import GenerationJSON.TraductionJSON.ProgrammeToBlock;
import ReconnaissanceAlgorithme.CubeDetection;

/**
 * Cette classe contient la m�thode principale de l'ensemble du projet. C'est cette classe qui r�alise l'int�gration 
 * entre la m�thode de reconnaissance d'un algorithme Scratch et la m�thode de transcription d'un programme en projet JSON. 
 * Le fichier en entr�e est un clich� de l'algorithme construit par l'utilisateur Algorithme.jpg qui est dans le sous-dossier ClichesAlgorithme et le fichier de sortie est
 * un projet Scratch 3.0 au format .sb3 qui se trouve directement dans le dossier de travail
 * @author Jean-Baptiste
 *
 */
public class CreationScratch {
	
	private final static float gamma = 0.9f;
	private final static String fichierAlgorithme = "C:/Users/Jean-Baptiste/Desktop/IntegrationComplete/ClichesAlgorithmes/Algorithme.jpg";

	public static void main(String[] args) throws Exception {
		
		/* ENTREES DU PROGRAMME PRINCIPAL */
		 
		  InputStream input = new FileInputStream("project_original.json");
		  OutputStream output = new FileOutputStream("project.json");
		  ObjectMapper objectMapper = new ObjectMapper();
		  
		  JsonNode projet = objectMapper.readValue(input,JsonNode.class);
          JsonNode spriteScript = projet.get("targets").get(1).get("blocks");
          JsonNode messagesNode = projet.get("targets").get(0).get("broadcasts");
          JsonNode variablesNode = projet.get("targets").get(0).get("variables");
          String jsonString = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(spriteScript);
          
          System.out.println(jsonString);
          
          LinkedList<TreeMap<Integer, ETypeBlocks>> associations = CodesSemantique.association;
		  LinkedList<Entite> programme = new LinkedList<Entite>();
		  LinkedList<Block> algorithme = new LinkedList<Block>();
		  LinkedList<Variable> variables = new LinkedList<Variable>(Arrays.asList(new Variable()));
		  LinkedList<Message> messages = new LinkedList<Message>(Arrays.asList(new Message("message1")));
		  System.out.println(CodesSemantique.association);
		  
		  /* RECONNAISSANCE DU PROGRAMME */
		  
		  
		  programme = CubeDetection.reconnaitAlgorithme(fichierAlgorithme,gamma);
		  System.out.println(programme);
		  
		  
		  
		  /* PHASE DE TRANSCRIPTION EN JSON */
		  
		  
		  
		  ProgrammeToBlock transcript = new ProgrammeToBlock();
		  ListIterator<Entite> li = programme.listIterator(0);
		  messages = transcript.getMessages(algorithme);
		  transcript.transcriptionBlocksJava(programme, algorithme, variables);
		  spriteScript = transcript.traductionAlgorithme(algorithme);
		  messagesNode = transcript.traductionMessages(messages, algorithme);
		  variablesNode = transcript.traductionVariables(variables);
		  
		  JsonNode targets = projet.get("targets");
		  JsonNode sprite = targets.get(1);
		  if (spriteScript != null) {
		  ((ObjectNode) sprite).set("blocks",spriteScript);
		  }
		  JsonNode scene = targets.get(0);
		  if(messagesNode != null) {
			  ((ObjectNode) scene).set("broadcasts",messagesNode);
		  }
		  if(variablesNode != null) {
			  ((ObjectNode) scene).set("variables", variablesNode);
		  }
		  
	     
		  jsonString = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(projet);
		  System.out.println( jsonString);
		  JsonFactory factory = new JsonFactory();
		  ObjectWriter writer = objectMapper.writer(new DefaultPrettyPrinter());
		  writer.writeValue(output, projet);
		  System.out.println("fait");
		  
		  
		  
		  
		  System.out.println("ereer");
		  
		  // Je Copie le fichier original et l'enregistre dans un fichier zip qui sera modifié
		  File originalfile =new File("C:\\Users\\Jean-Baptiste\\Desktop\\IntegrationComplete\\ScratchOriginal.zip");
		  File newfile =new File("C:\\Users\\Jean-Baptiste\\Desktop\\IntegrationComplete\\MonProjet.sb3");
		  File oldfile =new File("C:\\Users\\Jean-Baptiste\\Desktop\\IntegrationComplete\\MonProjet.zip");
		  
		  
		  ZipFile zipSrc = new ZipFile(originalfile);
		    ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(oldfile));

		    Enumeration srcEntries = zipSrc.entries();
		    while (srcEntries.hasMoreElements()) {
		            ZipEntry entry = (ZipEntry) srcEntries.nextElement();
		            ZipEntry newEntry = new ZipEntry(entry.getName());
		            zos.putNextEntry(newEntry);

		            BufferedInputStream bis = new BufferedInputStream(zipSrc
		                            .getInputStream(entry));

		            while (bis.available() > 0) {
		                    zos.write(bis.read());
		            }
		            zos.closeEntry();

		            bis.close();
		    }
		    zos.finish();
		    zos.close();
		    zipSrc.close();
		  
		    /* ECRITURE DANS LE FICHIER ZIP */
			  
			  Map<String, String> env = new HashMap<>(); 
			  env.put("create", "true");
			  Path path = Paths.get("C:\\Users\\Jean-Baptiste\\Desktop\\IntegrationComplete\\MonProjet.zip");
			  URI uri = URI.create("jar:" + path.toUri());
			  try (FileSystem fs = FileSystems.newFileSystem(uri, env))
			  {
			      Path nf = fs.getPath("project.json");
			      try (Writer writer2 = Files.newBufferedWriter(nf, StandardCharsets.UTF_8, StandardOpenOption.CREATE)) {
			          writer2.write(jsonString);
			      }
			  }
		    
		    
		  /* CONVERSION DU FICHIER SB3 */
		  System.out.println(newfile.exists());
		  
		  if (newfile.exists()) {
			  System.out.println("projet scratch à supprimer !!!");
			  newfile.delete();
			  
		  }
		  
		  if(oldfile.renameTo(newfile)){
				System.out.println("Rename succesful");
			}else{
				System.out.println("Rename failed");
			}
	}

}
