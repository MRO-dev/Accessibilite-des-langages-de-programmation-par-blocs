package GenerationJSON.ScratchBlocks;

/**
 * Classe mod�lisant le bloc de fin du programme Scratch 3.0
 * @author Jean-Baptiste
 *
 */
public class BlockDeFin extends Block {

	public BlockDeFin() {
		super("Bloc de Fin");
		// TODO Auto-generated constructor stub
	}

}
