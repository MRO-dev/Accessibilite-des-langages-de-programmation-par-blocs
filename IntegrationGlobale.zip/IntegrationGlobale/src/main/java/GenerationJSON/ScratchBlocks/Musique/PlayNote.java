package GenerationJSON.ScratchBlocks.Musique;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;

public class PlayNote extends Block{
	
	public PlayNote() {
		super("music_playNoteForBeats");
		nombreInputs = 2;
		String[] setInputTitles = new String[] {"NOTE", "BEATS"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "60");
		simpleInput.put(2, "0.25");
	}

}
