package GenerationJSON.ScratchBlocks.Musique;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;

public class SetTempo extends Block{
	
	public SetTempo() {
	super("music_setTempo");
	nombreInputs = 1;
	String[] setInputTitles = new String[] {"TEMPO"};
	inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
	simpleInput.put(1, "10");
	}

}
