/**
 * Package mod�lisant l'ensemble des blocs de Musique Scratch.
 * @author Jean-Baptiste Marco
 */

package GenerationJSON.ScratchBlocks.Musique;