package GenerationJSON.ScratchBlocks.Musique;

import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.ScratchBlocks.VariableEntreeBloc;

public class Tempo extends VariableEntreeBloc{
	
	public Tempo() {
		super("music_getTempo");
		// TODO Auto-generated constructor stub
	}

}
