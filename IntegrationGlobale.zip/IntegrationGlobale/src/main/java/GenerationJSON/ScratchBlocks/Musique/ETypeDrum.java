package GenerationJSON.ScratchBlocks.Musique;

/**
 * Enum�ration des diff�rents types de batteries
 * @author Jean-Baptiste
 *
 */
public enum ETypeDrum {
	
	SnareDrum("1"),BassDrum("2"),SideStick("3"), CrashCymbal("4"), OpenHiHat("5"),ClosedHiHat("6"),Tambourine("7"),
	HandClap("8"), Claves("9"), WoodBlock("10"), CowBell("11"), Triangle("12"), Bongo("13"), Conga("14"), 
	Cabasa("15"), Guiro("16"), Vibraslap("17"), Cuica("18");
	
	private String name;
	
	

	private ETypeDrum(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
}
