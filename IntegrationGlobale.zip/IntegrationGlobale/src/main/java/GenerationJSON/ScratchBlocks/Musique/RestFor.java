package GenerationJSON.ScratchBlocks.Musique;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;

public class RestFor extends Block{
	
	public RestFor() {
		super("music_restForBeats");
		nombreInputs = 1;
		String[] setInputTitles = new String[] {"BEATS"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "0.25");
	}
	

}
