package GenerationJSON.ScratchBlocks.Musique;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.TreeMap;

import org.apache.commons.lang3.mutable.MutableInt;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import GenerationJSON.Outils.EFamilleEntite;
import GenerationJSON.Outils.ETypeBlocks;
import GenerationJSON.Outils.Entite;
import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.ScratchBlocks.Variable;
import GenerationJSON.ScratchBlocks.Motion.CodesMotion;
/**
 * Classe mod�lisant le menu d�roulant de la batterie
 * @author Jean-Baptiste
 *
 */
public class MenuDrum extends Block{
	
	public MenuDrum(){
	super("music_menu_DRUM");
	nombreInputs = 0;
	nombreFields = 1;
	isInputVariable = true;
	String[] setFieldTitles = new String[] {"DRUM"};
	fieldTitles = new ArrayList<String> (Arrays.asList(setFieldTitles));
	fields.put(1, "1");
	}
	
	@Override
	public JsonNode genereField() {
			ObjectMapper mapper = new ObjectMapper();
			JsonNode dataNode = mapper.createObjectNode();
			JsonNode fieldNode = mapper.createObjectNode();
			ListIterator<String> li = fieldTitles.listIterator();
			Integer indexFields = 1;
			while (li.hasNext()) {
				String fieldName = li.next();
				String json = "{\r\n" + 
							"						\""+fieldName+"\": [\r\n" + 
							"							\""+fields.get(indexFields)+"\"\r\n" + 
							"						]\r\n" + 
							"					}";
					try {
						((ObjectNode) dataNode).put(fieldName,mapper.readTree(json).get(fieldName));
						((ObjectNode) fieldNode).put("fields", dataNode);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					 indexFields++;
					}
					
					return dataNode;
				   
					}
	@Override
	public boolean ajoutInputsBloc(LinkedList<Entite> programme, LinkedList<Variable> variables, MutableInt indexEntrees, LinkedList<TreeMap<Integer, ETypeBlocks>> association,LinkedList<Block> algorithme) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
		Entite entree;
		if (indexEntrees.getValue()>=programme.size()-1) {
			System.out.println("Fin de l'algorithme !!!");
			return false;
		}
		indexEntrees.add(1);
		entree = programme.get(indexEntrees.getValue());
		if (entree.getType() == EFamilleEntite.TopCode) {
			if (CodesDrum.codesDrums.containsKey(Integer.valueOf(entree.getValeur()))) {
				fields.put(1, CodesDrum.codesDrums.get(Integer.valueOf(entree.getValeur())).getName());
				return true;
			}else {
				System.out.println("Inconsistance !!!");
				return false;
			}
		}else {
			System.out.println("Inconsistance !!!");
			return false;
		}
		

}
}
