package GenerationJSON.ScratchBlocks.Musique;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.ListIterator;
import java.util.TreeMap;
import java.util.TreeSet;

import GenerationJSON.Outils.InsertionGeneriqueMap;

/**
 * Classe impl�mentant l'association codes :: instruments
 * @author Jean-Baptiste
 *
 */
public class CodesInstrument {
	
	private static final Integer[] SET_VALUES = new Integer[] { 31, 47, 55, 59, 61, 79, 87, 91, 93, 103, 107, 109,
			115, 117, 121, 143, 151, 155, 157, 167, 171};
	private static final TreeSet<Integer> monTreeSet = new TreeSet<Integer>(Arrays.asList(SET_VALUES));
	private static final ArrayList<Integer> codesUtiles = new ArrayList<Integer>(monTreeSet);
	private static InsertionGeneriqueMap<Integer, ETypeInstrument, TreeMap<Integer,ETypeInstrument>> igm = new InsertionGeneriqueMap<Integer, ETypeInstrument, TreeMap<Integer,ETypeInstrument>>();
 	public static final TreeMap<Integer, ETypeInstrument> codesInstruments;
 	static {
 		 TreeMap<Integer, ETypeInstrument> auxMap = new TreeMap<Integer,ETypeInstrument>();
         TreeSet<Integer> monTreeSet = new TreeSet<Integer>(Arrays.asList(SET_VALUES));
 		 ArrayList<Integer> codesUtiles = new ArrayList<Integer>(monTreeSet);
 		 if (codesUtiles.size()!= ETypeInstrument.values().length) {
 			System.out.println("Inconsistance des entr�es");
 		 }
 		 else {
 			ListIterator<Integer> li = codesUtiles.listIterator();
 			for (ETypeInstrument valeur : ETypeInstrument.values()) {
 				igm.put(auxMap,li.next(),valeur);				
 			}
 		}
         codesInstruments = auxMap;
     }
 	
 	private CodesInstrument() {}
	
}


