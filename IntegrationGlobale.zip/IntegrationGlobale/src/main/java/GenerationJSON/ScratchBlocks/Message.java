package GenerationJSON.ScratchBlocks;

import java.io.IOException;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * Classe mod�lisant un message(Event) Scratch 3.0
 * Cette classe h�rite de la classe Block
 * @author Jean-Baptiste
 *
 */
public class Message extends Block{

	public Message(String msg) {
		super(msg);
		setId(msg);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * Red�finition de la m�thode traduitCode pour g�n�rer un noeud JSON adapt� aux instances de la classe Message
	 */
	@Override
	public JsonNode traduitCode() {
		ObjectMapper mapper = new ObjectMapper();
		JsonNode rootNode = mapper.createObjectNode();
		String inputName = getId();
		String json = "{\r\n" + 
				"            \""+getId()+"\": \r\n" + 				
				"              \""+getId()+"\""+
				"          }";
		try {
			rootNode = mapper.readTree(json).get(inputName);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return rootNode;
	}

}
