package GenerationJSON.ScratchBlocks;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.TreeMap;

import org.apache.commons.lang3.mutable.MutableInt;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import GenerationJSON.Outils.CategoriesBlocs;
import GenerationJSON.Outils.EFamilleEntite;
import GenerationJSON.Outils.ETypeBlocks;
import GenerationJSON.Outils.Entite;
import GenerationJSON.TraductionJSON.ICode;

/**
 * Classe mod�lisant un bloc de Scratch 3.0
 * Cette classe impl�mente l'interface ICode qui servira � transcrire les �l�ments contenus dans un Block dans un noeud JSON
 * @author Jean-Baptiste
 *
 */
public abstract class Block implements ICode{
	
	private static int numero;//numero d'instance du bloc 
	private String id;//identifiant du bloc
	private String opcode;//code opcode du bloc conform�ment � la structuration JSON d'un projet Scratch	
	private String next = null;//identifiant du bloc suivant
	private String parent = null;//identifiant du bloc parent
	private boolean toplevel = true;//d�termine si le bloc est positionn� au sommet i.e. c'est le premier bloc de l'algorithme
	private boolean shadow = false;//d�termine si le bloc est cach�
	protected boolean isInputVariable = false;
	private int abscisse = 500;//abscisse (500 par d�faut)
	private int ordonnee = 50;//ordonn�e (100 par d�faut)
	protected int taille = 65;
	protected int nombreInputs;//nombre de donn�es en entr�es du bloc (inputs)
	protected int nombreFields;//nombre de champs (liste d�roulante) contenus au sein d'un bloc Scratch
	protected TreeMap<Integer, String> simpleInput = new TreeMap<Integer,String>();//d�termine les inputs simples (entr�es alphanum�riques)
	protected TreeMap<Integer, Block> blockInput = new TreeMap<Integer,Block>();//d�termine les inputs sous formes de blocs (blocs op�rateurs) 
	protected TreeMap<Integer, String> fields = new TreeMap<Integer,String>();//d�termine les champs du bloc
	protected ArrayList<String> inputTitles;//liste des noms des inputs
	protected ArrayList<String> fieldTitles;//liste des noms des champs
	
	
	
	
	
	/**
	 * Constructeur
	 * @param opcode : le code d�finissant la nature du bloc
	 */
	public Block(String opcode) {
		id = "Bloc_Numero_"+getNumero();
		numero++;
		this.opcode = opcode;
	}	

	
	public static int getNumero() {
		return numero;
	}
	
	public String getId() {
		return id;
	}
	
	
	public void setId(String id) {
		this.id = id;
	}


	public String getOpcode() {
		return opcode;
	}
	
	public String getNext() {
		return next;
	}
	public void setNext(String next) {
		this.next = next;
	}
	public String getParent() {
		return parent;
	}
	public void setParent(String parent) {
		this.parent = parent;
		toplevel = false;
	}
	public boolean isToplevel() {
		return toplevel;
	}
	public void setToplevel(boolean toplevel) {
		this.toplevel = toplevel;
	}
	public boolean isShadow() {
		return shadow;
	}
	public void setShadow(boolean shadow) {
		this.shadow = shadow;
	}
	
	
	public boolean isInputVariable() {
		return isInputVariable;
	}


	public void setInputVariable(boolean isInputVariable) {
		this.isInputVariable = isInputVariable;
	}


	public int getAbscisse() {
		return abscisse;
	}
	public void setAbscisse(int abscisse) {
		this.abscisse = abscisse;
	}
	public int getOrdonnee() {
		return ordonnee;
	}
	public void setOrdonnee(int ordonnee) {
		this.ordonnee = ordonnee;
	}
		
	public int getTaille() {
		return taille;
	}


	public void setTaille(int taille) {
		this.taille = taille;
	}


	/**
	 * Impl�mentation de traduitCode de l'interface ICode.
	 * Cette m�thode g�n�re ainsi le script JSON associ� � une instance h�ritant de la classe Block.
	 */
	public JsonNode traduitCode() {
		ObjectMapper mapper = new ObjectMapper();
		JsonNode rootNode = mapper.createObjectNode();

		JsonNode childNode = mapper.createObjectNode();
		((ObjectNode) childNode).put("opcode",opcode);
		if (next != null) {((ObjectNode) childNode).put("next",next);
					}
		else {((ObjectNode) childNode).putNull("next");			
		}
		if (parent != null) {((ObjectNode) childNode).put("parent",parent);
		}
		else {((ObjectNode) childNode).putNull("parent");	}
		JsonNode inputNode = genereInput();
		if (inputNode == null) {
			((ObjectNode) childNode).put("inputs", mapper.createObjectNode());			
		}
		else {
		((ObjectNode) childNode).put("inputs", inputNode);
		}
		JsonNode fieldNode = genereField();
		if (fieldNode == null) {
			((ObjectNode) childNode).put("fields",mapper.createObjectNode());					
		}
		else {
			((ObjectNode) childNode).put("fields",fieldNode);			
		}		
		((ObjectNode) childNode).put("topLevel",isToplevel());
		((ObjectNode) childNode).put("shadow",isShadow());
		if (parent ==  null) {
			((ObjectNode) childNode).put("x",getAbscisse());
			((ObjectNode) childNode).put("y",getOrdonnee());
		}
//		((ObjectNode) rootNode).put(id, childNode);
		
		return childNode;
	}
	
	/**
	 * Genere l'ensemble des inputs d'un bloc sous la forme d'un noeud Json
	 * @return JsonNode
	 */
	public JsonNode genereInput() {
		if (nombreInputs == 0) {
			return null;
		}
		else {  
			ObjectMapper mapper = new ObjectMapper();
			JsonNode dataNode = mapper.createObjectNode();
			JsonNode inputNode = mapper.createObjectNode();
			Integer indexInputs = 1;
			ListIterator<String> li = inputTitles.listIterator();
			while (li.hasNext()) {
				String inputName = li.next();
				if (blockInput.get(indexInputs)!=null) {
					if (blockInput.get(indexInputs) instanceof Variable) {
						String json = "{\r\n" + 
								"            \""+inputName+"\": [\r\n" + 
								"              3,\r\n" + 
								"              [\r\n" + 
								"                12,\r\n" + 
								"                \""+blockInput.get(indexInputs).getId()+"\",\r\n" + 
								"                \""+blockInput.get(indexInputs).getId()+"\"\r\n" + 
								"              ],\r\n" +
								"              [\r\n" + 
								"                4,\r\n" + 
								"                \""+simpleInput.get(indexInputs)+"\"\r\n" + 
								"              ]\r\n" + 
								"            ]\r\n" + 
								"          }";
						try {
							((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
							((ObjectNode) inputNode).put("inputs", dataNode);
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}else {						
					String json = "{\r\n" + 
							"            \""+inputName+"\": [\r\n" + 
							"              3,\r\n" + 
							"              \""+blockInput.get(indexInputs).getId()+"\",\r\n" + 
							"              [\r\n" + 
							"                4,\r\n" + 
							"                \""+simpleInput.get(indexInputs)+"\"\r\n" + 
							"              ]\r\n" + 
							"            ]\r\n" + 
							"          }";
					try {
						((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
						((ObjectNode) inputNode).put("inputs", dataNode);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}	}				
				else {
					String json = "{\r\n" + 
							"            \""+inputName+"\": [\r\n" + 
							"              1,\r\n" + 
							"              [\r\n" + 
							"                4,\r\n" + 
							"                \""+simpleInput.get(indexInputs)+"\"\r\n" + 
							"              ]\r\n" + 
							"            ]\r\n" + 
							"          }";
						
					try {
						((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
						((ObjectNode) inputNode).put("inputs", dataNode);
							//rootNode.put(Blockinput);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					indexInputs++;
					}
				
			return dataNode;
			}

		}
	
	
	/**
	 * Genere l'ensemble des champs d'un bloc Scratch sous la forme d'un noeud Json
	 * @return JsonNode, noeud JsonNode comprenant l'ensemble des champs du bloc
	 */
	public JsonNode genereField() {
		return null;
	}
	
	/**
	 * Instancie le bloc suivant au bloc qui appelle cette m�thode, connaissant la donn�e d'un algorithme Scratch repr�sent� par une liste d'entit�s
	 * ainsi que de l'index courant de cette liste.
	 * 
	 * @param programme LinkedList(Entite), le programme reconnu par la reconnaissance d'images
	 * @param indexEntrees, l'index courant du programme
	 * @param associations, la TreeMap mod�lisant l'association entre les TopCodes et les Blocs
	 * @param variables LinkedList(Variable), la liste des variables de l'algorithme en construction
	 * @param algorithme LinkedList(Block), l'algorithme en construction mod�lis� par une liste de Block
	 * @return Block, le block suivant
	 * @throws ClassNotFoundException : classe recherch�e inexistante ou non impl�ment�e
	 * @throws InstantiationException : erreur lors de l'instanciation d'un Block
	 * @throws IllegalAccessException : acces ill�gal lors de l'appel de Class.forName
	 * @throws NoSuchMethodException : la m�thode que l'on souhaite invoquer n'existe pas
	 * @throws SecurityException : erreur de s�curit�
	 * @throws IllegalArgumentException : argument illicite lors de l'invocation d'une m�thode par reflection
	 * @throws InvocationTargetException : erreur g�n�r�e lors de l'invocation d'une m�thode (cible illicite)
	 */
	public Block construitBlocSuivant(LinkedList<Entite> programme, MutableInt indexEntrees, LinkedList<TreeMap<Integer, ETypeBlocks>> associations, LinkedList<Variable> variables, LinkedList<Block> algorithme) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
		TreeMap<Integer, ETypeBlocks> association = associations.get(0);
		if (indexEntrees.getValue()>= programme.size()-1) {
			System.out.println("Algorithme terminé !!!!");
			return null;
		}
		System.out.println("teteet");
		Entite entree;
//		int iBlocSuivant = indexEntrees;
//		if (blockInput.size()==0) {
		indexEntrees.add(1);
	    entree = programme.get(indexEntrees.getValue());
	    System.out.println("mon entrée tadada"+entree);
			   
				
				
				if (entree.getType() == EFamilleEntite.TopCode) {
					
					if (association.get(Integer.valueOf(entree.getValeur())) == ETypeBlocks.NouveauxBlocs) {
						
						if (indexEntrees.getValue()>= programme.size()-1) {
							System.out.println("Algorithme terminé !!!!");
							return null;
						}							
						indexEntrees.add(1);
					    entree = programme.get(indexEntrees.getValue());
					    association = associations.get(1);
						
					}
					if (!CategoriesBlocs.nonInstanciables.contains(association.get(Integer.valueOf(entree.getValeur())))) {
						Class<?> cls = Class.forName(association.get(Integer.valueOf(entree.getValeur())).getName());
						Object block = cls.newInstance();
						if (block instanceof Variable) {
							Method met = cls.getMethod("setParent",String.class);
							met.invoke(block, getId());
							met = cls.getMethod("construitBlocSuivant", LinkedList.class, MutableInt.class, LinkedList.class,LinkedList.class, LinkedList.class);
							Object newBlock = met.invoke(block, programme, indexEntrees, associations, variables, algorithme);
							if (newBlock != null) {
								met = cls.getMethod("getId");
								String idNext = (String) met.invoke(newBlock);
								setNext(idNext);
							}
							
							return (Block) newBlock;
							
						}
						if (!CategoriesBlocs.parents.contains(association.get(Integer.valueOf(entree.getValeur())))) {
							Method method = cls.getMethod("setParent",String.class);
							method.invoke(block, getId());
							method = cls.getMethod("getId");
							String idNext = (String) method.invoke(block);
							setNext(idNext);
						}						
						return (Block) block;
						
					}else {
						System.out.println("JB Kho Ouais");
						return null;
					}
					
				
				
				
				
				}else {
					System.out.println("Inconsistance des entrées");
					return null;
					
				}
	}
//			}
//			else {
//				System.out.println("Inconsistance des entrées");
//			}
//				return null;
//			
//		}
//		
//		else {
//			while (indexEntrees.getValue()<programme.size())
//			{
//			entree = li.next();
//			indexEntrees.add(1);
//			if (entree.getType() == EFamilleEntite.TopCode) {
//				if (CategoriesBlocs.nonInstanciables.contains(association.get(Integer.valueOf(entree.getValeur())))) {
//					return null;
//				}
//	/*ajouter union logique bool*/if (!Stream.concat(CategoriesBlocs.operationsElementairesUnaires.stream(),CategoriesBlocs.operationsElementairesBinaires.stream()).collect(Collectors.toList()).contains(association.get(Integer.valueOf(entree.getValeur())))){
//					
//					Class<?> cls = Class.forName(association.get(Integer.valueOf(entree.getValeur())).getName());
//					Object block = cls.newInstance();
//					Method method = cls.getMethod("setParent",String.class);
//					method.invoke(block, getId());
//					method = cls.getMethod("getId");
//					String idNext = (String) method.invoke(block);
//					setNext(idNext);
//					return (Block) block;
//					
//				}
//				
//			}
//			else {
//				System.out.println("Inconsistance des entrées");
//				return null;
//			}
//
//			
//			
//			}
//		}

	

	/**
	 * M�thode ajoutant les inputs d'un bloc connaissant le programme Scratch reconnu optiquement repr�sent� sous forme
	 * d'une liste d'entit�s Java, la liste des variables du programme Scratch ainsi que l'index courant
	 * @param programme LinkedList(Entite), l'algorithme Scratch
	 * @param variables LinkedList(Variable) variables, la liste des variables
	 * @param indexEntrees MutableInt, l'index courant
	 * @param associations TreeMap, l'association entre TopCodes et Blocks Scratch
	 * @param algorithme LinkedList(Bl0ock), l'algorithme transcrit sous forme de liste de Blocks
	 * @return bool�en : vrai si l'ajout des inputs du blocs a �t� effectu� avec succ�s, false sinon (Inconsistance des donn�es) ou Algorithme termin�e (index en fin de liste)
	 * @throws ClassNotFoundException : classe que l'on veut instancier non trouv�e
	 * @throws InstantiationException : erreur lors de l'instanciation
	 * @throws IllegalAccessException : exception lev�e en cas d'acc�s Illegal pour la m�thode Class.forName
	 * @throws NoSuchMethodException : la m�thode que l'on a invoqu�e n'existe pas, r�f�rence de la m�thode mal �crite
	 * @throws SecurityException : exception de s�curit�
	 * @throws IllegalArgumentException : argument ill�gal pour la m�thode que l'on veut invoquer
	 * @throws InvocationTargetException : exception lev�e lors de l'appel � la m�thode que l'on souhaite invoquer
	 */
	public boolean ajoutInputsBloc(LinkedList<Entite> programme, LinkedList<Variable> variables, MutableInt indexEntrees, LinkedList<TreeMap<Integer, ETypeBlocks>> associations,LinkedList<Block> algorithme) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
		TreeMap<Integer, ETypeBlocks> association = associations.get(0);
		Integer inputKey = 1;
		Entite entree;
		if (indexEntrees.getValue()>=programme.size()-1) {
			System.out.println("Fin de l'algorithme !!!");
			return false;
		}
		System.out.println("nombreInputs = "+nombreInputs);
		while (inputKey<=nombreInputs && indexEntrees.getValue()<programme.size()-1) {
			        association = associations.get(0);
					System.out.println("index Entee jb " + indexEntrees);
					System.out.println("inputkey = " +inputKey);
					indexEntrees.add(1);
					entree = programme.get(indexEntrees.getValue());
					System.out.println(entree);
					
					if (entree.getType() == EFamilleEntite.TopCode) {
						System.out.println("jb est par ci");
						if (association.get(Integer.valueOf(entree.getValeur())) == ETypeBlocks.NouveauxBlocs) {
							
							if (indexEntrees.getValue()>= programme.size()-1) {
								System.out.println("Algorithme terminé !!!!");
								return false;
							}						
							indexEntrees.add(1);
						    entree = programme.get(indexEntrees.getValue());
						    association = associations.get(1);
							
						}
//						if (!CategoriesBlocs.operations.contains(association.get(Integer.valueOf(entree.getValeur())))) {
//							System.out.println("pas une op�ration donc pas d'input");
//							indexEntrees.add(-1);
//							System.out.println("new indexEntree " + indexEntrees);
//						}else {
							
							if (!CategoriesBlocs.nonInstanciables.contains(association.get(Integer.valueOf(entree.getValeur())))) {
							Class<?> cls = Class.forName(association.get(Integer.valueOf(entree.getValeur())).getName());
							Block block = (Block) cls.newInstance();
							Method method = cls.getMethod("setParent",String.class);
							method.invoke(block, getId());
							method = cls.getMethod("ajoutInputsBloc",LinkedList.class, LinkedList.class, MutableInt.class,LinkedList.class, LinkedList.class );
							System.out.println(block);
							method.invoke(block,programme,variables, indexEntrees,associations, algorithme);
							System.out.println("azaz");
							blockInput.put(inputKey, block);
							if (block.getClass() == Variable.class) {
//								variables.add((Variable) block);
								System.out.println("variable");
							}
							else {
								algorithme.add(block);
							}						
							}
							else {
								System.out.println("Oh c'est non instanciable !!!!!");
								return false;
							}
							
//						}
						
						
					}
					else {
						System.out.println("jb est par là");
						simpleInput.put(inputKey, entree.getValeur());

					
						
					}
					

					System.out.println(inputKey + "lalala");
					inputKey++;
					
					System.out.println(inputKey + "ppppa");
					System.out.println(inputKey<=nombreInputs && indexEntrees.getValue()<programme.size()-1);
					
				}
		return true;
			
			
			
			
		}
	
//	/**
//	 * M�thode d'ajout de champs d'un bloc conaissant le programme reconnu et l'index courant
//	 * @param programme LinkedList<Entite>
//	 * @param indexEntrees MutableInt
//	 * @param association TreeMap<Integer, ETypeBlocks>
//	 * @param algorithme LinkedList<Block>
//	 */
//	public void ajoutInputsFields(LinkedList<Entite> programme, MutableInt indexEntrees, LinkedList<TreeMap<Integer, ETypeBlocks>> associations,LinkedList<Block> algorithme) {
//		
//	}
		

	/**
	 * M�thode statique de cr�ation d'un nouveau bloc conaissant le TopCode correspondant
	 * @param entree Entite en entr�e
	 * @param associations associations entre TopCodes et Blocks Scratch
	 * @param programme LinkedList(Entite) : le programme reconnu
	 * @param indexEntrees : l'index courant de la liste programme
	 * @return Block nouvellement cr�� et qui correspond au TopCode associ�
	 * @throws NumberFormatException : exception due aux param�tres num�riques appel�s 
	 * @throws ClassNotFoundException : en cas d'inexistance d'une classe que l'on veut instancier
	 * @throws InstantiationException : erreur d'instanciation
	 * @throws IllegalAccessException : erreur lev� en cas d'acc�s ill�gal lors de l'invocation de la m�thode Class.forName
	 */
	public static Block creationBloc(Entite entree, MutableInt indexEntrees, LinkedList<Entite> programme, LinkedList<TreeMap<Integer, ETypeBlocks>> associations) throws NumberFormatException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		TreeMap<Integer, ETypeBlocks> association = associations.get(0);
		if (entree.getType() == EFamilleEntite.TopCode) {
			if (association.get(Integer.valueOf(entree.getValeur())) == ETypeBlocks.NouveauxBlocs) {
				
				if (indexEntrees.getValue()>= programme.size()-1) {
					System.out.println("Algorithme terminé !!!!");
					return null;
				}						
				indexEntrees.add(1);
			    entree = programme.get(indexEntrees.getValue());
			    association = associations.get(1);
				
			}
			Class<?> cls = Class.forName(association.get(Integer.valueOf(entree.getValeur())).getName());
			Block block = (Block) cls.newInstance();
			return block;
		}else {
			return null;
		}
		
	}


	@Override
	public String toString() {
		return "Block [id=" + id + ", opcode=" + opcode + ", next=" + next + ", parent=" + parent + ", toplevel="
				+ toplevel + ", shadow=" + shadow + ", abscisse=" + abscisse + ", ordonnee=" + ordonnee
				+ ", nombreInputs=" + nombreInputs + ", simpleInput=" + simpleInput + ", blockInput=" + blockInput
				+ ", inputTitles=" + inputTitles + ", fieldTitles=" + fieldTitles + "]";
	}
	
	

//	public JsonNode traiteBlock(ArrayList<Integer> codes, Integer indexCodes, ArrayList<String> inputs, Integer indexInputs, TreeMap<Integer, ETypeBlocks> association) {
//			ETypeBlocks blCourant = association.get(codes.get(indexCodes));
//			indexCodes++;
//			Class<?> clsCourante = Class.forName(blCourant.toString());
//			Object blockCourant = clsCourante.newInstance();
//			if (nombreInputs == 0) {
//				ETypeBlocks blCourant = association.get(codes.get(indexCodes));
//				indexCodes++;
//				Class<?> clsCourante = Class.forName(blCourant.toString());
//				Object blockCourant = clsCourante.newInstance();
//				ETypeBlocks blSuivant = association.get(codes.get(indexCodes));
//				Class<?> clsSuivante = Class.forName(blSuivant.toString());
//				Object blockInput = clsSuivante.newInstance();
//				Method method = clsSuivante.getMethod("setParent", String.class);
//				method.invoke(blockSuivant);
//				Method method = clsCourante.getMethod("setNext");
//				method.invoke(blockCourant);
//				Method method = clsCourante.getMethod("traduitCode");
//				method.invoke(blockCourant);
//				
//			}
//			else {
//				int j;
//				while (j<=i) {
//					if (blockInput.containsKey(j)) {
//						ETypeBlocks blSuivant = association.get(codes.get(indexCodes));
//						Class<?> clsSuivante = Class.forName(blSuivant.toString());
//						Object blockInput = clsSuivante.newInstance();
//						Method method = clsSuivante.getMethod("setParent", String.class);
//						method.invoke(blockSuivant);
//						
//						method = clsSuivante.getMethod("setBlockInput")
//						method.invoke(blockCourant, blockSuivant);getClass();
//						
//						traduitCode();
//						
//					}
//					else {
//						String inputCourant = inputs.get(indexInputs);
//						indexInputs++;
//						Method method = clsSuivante.getMethod("setInput", String.class);
//						putInput(1,inputCourant);
//						method.invoke(blockSuivant);
//						
//						
//						
//						
//					}
//				}
//			ETypeBlocks blCourant = association.get(codes.get(indexCodes));
//			indexCodes++;
//			Class<?> clsCourante = Class.forName(blCourant.toString());
//			Object blockCourant = clsCourante.newInstance();
//			ETypeBlocks blSuivant = association.get(codes.get(indexCodes));
//			Class<?> clsSuivante = Class.forName(blSuivant.toString());
//			Object blockInput = clsSuivante.newInstance();
//			Method method = clsSuivante.getMethod("setParent", String.class);
//			method.invoke(blockSuivant);
//			
//			method = clsSuivante.getMethod("setBlockInput")
//			method.invoke(blockCourant, blockSuivant);getClass();
//			
//			traduitCode();
//			
//			
//			
//			Method method = cls.getMethod("getOpcode");
//			String opcode = (String) method.invoke(obj);
//			System.out.println(opcode);
//		    System.out.println("Vous avez juste la moyenne.");
//		    
//		    
//		    break;
//		  case 20:
//		    System.out.println("Parfait !");
//		    break;
//		  default:
//		    System.out.println("Il faut davantage travailler.");
//		}
//	}
}

		
		    
		    