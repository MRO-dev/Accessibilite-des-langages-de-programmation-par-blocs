package GenerationJSON.ScratchBlocks.Events;

import GenerationJSON.ScratchBlocks.Block;

public class WhenClone extends DebutAlgo{

	public WhenClone() {
		super("control_start_as_clone");
		
		// TODO Auto-generated constructor stub
	}

}
