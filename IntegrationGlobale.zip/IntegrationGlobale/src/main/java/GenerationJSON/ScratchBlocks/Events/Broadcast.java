package GenerationJSON.ScratchBlocks.Events;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.TreeMap;

import org.apache.commons.lang3.mutable.MutableInt;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import GenerationJSON.Outils.EFamilleEntite;
import GenerationJSON.Outils.ETypeBlocks;
import GenerationJSON.Outils.Entite;
import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.ScratchBlocks.Variable;

public class Broadcast extends Block{

	public Broadcast() {
		super("event_broadcast");
		nombreInputs = 1;
		String[] setInputTitles = new String[] {"BROADCAST_INPUT"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "message1");
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public JsonNode genereInput() {
		if (nombreInputs == 0) {
			return null;
		}
		else {  
			ObjectMapper mapper = new ObjectMapper();
			JsonNode dataNode = mapper.createObjectNode();
			JsonNode inputNode = mapper.createObjectNode();
			Integer indexInputs = 1;
			ListIterator<String> li = inputTitles.listIterator();
			while (li.hasNext()) {
				String inputName = li.next();
				if (blockInput.get(indexInputs)!=null) {
					String json = "{\r\n" + 
							"            \""+inputName+"\": [\r\n" + 
							"              3,\r\n" + 
							"              \""+blockInput.get(indexInputs).getId()+"\",\r\n" + 
							"              [\r\n" + 
							"                4,\r\n" + 
							"                \""+simpleInput.get(indexInputs)+"\"\r\n" + 
							"              ]\r\n" + 
							"            ]\r\n" + 
							"          }";
					try {
						((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
						((ObjectNode) inputNode).put("inputs", dataNode);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
				else {
					String json = "{\r\n" + 
							"            \""+inputName+"\": [\r\n" + 
							"              1,\r\n" + 
							"              [\r\n" + 
							"                11,\r\n" + 
							"                \""+simpleInput.get(indexInputs)+ "\""+","+"\r\n" +
							"                \""+simpleInput.get(indexInputs)+"\"\r\n" +
							"              ]\r\n" + 
							"            ]\r\n" + 
							"          }";
						
					try {
						((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
						((ObjectNode) inputNode).put("inputs", dataNode);
							//rootNode.put(Blockinput);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					indexInputs++;
					}
				
			return dataNode;
			}

		}
	
	@Override
	public boolean ajoutInputsBloc(LinkedList<Entite> programme, LinkedList<Variable> variables, MutableInt indexEntrees, LinkedList<TreeMap<Integer, ETypeBlocks>> associations,LinkedList<Block> algorithme) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
		TreeMap<Integer, ETypeBlocks> association = associations.get(0);
		Entite entree;
		if (indexEntrees.getValue()>=programme.size()-1) {
			System.out.println("Fin de l'algorithme !!!");
			return false;
		}
		indexEntrees.add(1);
		entree = programme.get(indexEntrees.getValue());
		if (entree.getType() == EFamilleEntite.TopCode) {
			if (association.get(Integer.valueOf(entree.getValeur())) == ETypeBlocks.Broadcast ) {
				return true;
			}else {
				System.out.println("Inconsistance");
				return false;
			}
		}else {
			simpleInput.put(1, entree.getValeur());
			DebutAlgo.addMessage(entree.getValeur());
		}
		return true;
			
			
			
			
		}

	
	
	

}
