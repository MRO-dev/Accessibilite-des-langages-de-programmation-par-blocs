package GenerationJSON.ScratchBlocks.Events;

import java.util.LinkedList;

import GenerationJSON.ScratchBlocks.Block;

public abstract class DebutAlgo extends Block{

	protected static LinkedList<String> messages;
	
	public DebutAlgo(String opcode) {
		super(opcode);
		taille =85;
		
		// TODO Auto-generated constructor stub
	}

	public static LinkedList<String> getMessages() {
		return messages;
	}
	
	public static void addMessage (String message) {
		if (messages == null) {
			messages = new LinkedList<String>();
			messages.add(message);
		}else {
			if (!messages.contains(message)) {
				messages.add(message);
			}
		}
	}
	
	

}
