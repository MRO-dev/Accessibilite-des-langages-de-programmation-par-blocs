package GenerationJSON.ScratchBlocks.Events;

public class WhenFlag extends DebutAlgo{
	
	public WhenFlag() {
		super("event_whenflagclicked");
		
		// TODO Auto-generated constructor stub
	}
	
	

}
