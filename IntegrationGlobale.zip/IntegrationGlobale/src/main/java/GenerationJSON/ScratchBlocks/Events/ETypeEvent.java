package GenerationJSON.ScratchBlocks.Events;

/**
 * Enum�ration des diff�rents types d'�v�nements : Chronom�tre et Volume
 * @author Jean-Baptiste
 *
 */
public enum ETypeEvent {
	
	Chronometre("TIMER"), Volume("LOUDNESS");
	
	private String name;
	
	
	private ETypeEvent(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
