/**
 * Package mod�lisant l'ensemble des blocs d'�v�nement Scratch.
 * @author Jean-Baptiste Marco
 */

package GenerationJSON.ScratchBlocks.Events;