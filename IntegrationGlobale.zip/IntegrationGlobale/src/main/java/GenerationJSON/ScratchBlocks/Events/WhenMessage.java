package GenerationJSON.ScratchBlocks.Events;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.TreeMap;

import org.apache.commons.lang3.mutable.MutableInt;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import GenerationJSON.Outils.EFamilleEntite;
import GenerationJSON.Outils.ETypeBlocks;
import GenerationJSON.Outils.Entite;
import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.ScratchBlocks.Variable;
import GenerationJSON.ScratchBlocks.Motion.GoToMenu;

public class WhenMessage extends DebutAlgo{
	
	private String nom_message = "message1"; 

	public WhenMessage() {
		super("event_whenbroadcastreceived");
		
		nombreInputs = 0;
		String[] setFieldTitles = new String[] {"BROADCAST_OPTION"};
		fieldTitles = new ArrayList<String> (Arrays.asList(setFieldTitles));
		// TODO Auto-generated constructor stub
	}
	
	
	
	@Override
	public JsonNode genereField() {
		ObjectMapper mapper = new ObjectMapper();
		JsonNode dataNode = mapper.createObjectNode();
		JsonNode inputNode = mapper.createObjectNode();
		Integer indexInputs = 1;
		ListIterator<String> li ;
		li = fieldTitles.listIterator();
		while (li.hasNext()) {
			String inputName = li.next();
			
				String json = "{\r\n" + 
						"						\""+inputName+"\": [\r\n" + 
						"\""+nom_message+"\""+","+"\r\n"+
						"\""+nom_message+"\""+"\r\n"+
						"						]\r\n" + 
						"					}";
				try {
					((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
					((ObjectNode) inputNode).put("inputs", dataNode);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
				
			
			
			
		
		}
		
			
		return dataNode;
				   
					}
	
	
	

	@Override
	public boolean ajoutInputsBloc(LinkedList<Entite> programme, LinkedList<Variable> variables, MutableInt indexEntrees, LinkedList<TreeMap<Integer, ETypeBlocks>> associations,LinkedList<Block> algorithme) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
		TreeMap<Integer, ETypeBlocks> association = associations.get(0);
		Entite entree;
		if (indexEntrees.getValue()>=programme.size()-1) {
			System.out.println("Fin de l'algorithme !!!");
			return false;
		}
		indexEntrees.add(1);
		entree = programme.get(indexEntrees.getValue());
		if (entree.getType() == EFamilleEntite.TopCode) {
			if (association.get(Integer.valueOf(entree.getValeur())) == ETypeBlocks.WhenMessage ) {
				return true;
			}else {
				System.out.println("Inconsistance");
				return false;
			}
		}else {
			nom_message = entree.getValeur();
			if (messages == null) {
			messages = new LinkedList<String>();
			messages.add(nom_message);
			}else {
				if(!messages.contains(nom_message)) {
				messages.add(nom_message);
				}
			}
		}
		return true;
			
			
			
			
		}

	
	

}
