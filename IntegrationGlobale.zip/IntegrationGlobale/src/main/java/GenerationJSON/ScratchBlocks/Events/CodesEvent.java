package GenerationJSON.ScratchBlocks.Events;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.ListIterator;
import java.util.TreeMap;
import java.util.TreeSet;

import GenerationJSON.Outils.InsertionGeneriqueMap;
import GenerationJSON.ScratchBlocks.Musique.ETypeInstrument;

public class CodesEvent {
	
	private static final Integer[] SET_VALUES = new Integer[] { 31, 47};
	private static final TreeSet<Integer> monTreeSet = new TreeSet<Integer>(Arrays.asList(SET_VALUES));
	private static final ArrayList<Integer> codesUtiles = new ArrayList<Integer>(monTreeSet);
	private static InsertionGeneriqueMap<Integer, ETypeEvent, TreeMap<Integer,ETypeEvent>> igm = new InsertionGeneriqueMap<Integer, ETypeEvent, TreeMap<Integer,ETypeEvent>>();
 	public static final TreeMap<Integer, ETypeEvent> codesEvenement;
 	static {
 		 TreeMap<Integer, ETypeEvent> auxMap = new TreeMap<Integer,ETypeEvent>();
         TreeSet<Integer> monTreeSet = new TreeSet<Integer>(Arrays.asList(SET_VALUES));
 		 ArrayList<Integer> codesUtiles = new ArrayList<Integer>(monTreeSet);
 		 if (codesUtiles.size()!= ETypeEvent.values().length) {
 			System.out.println("Inconsistance des entr�es");
 		 }
 		 else {
 			ListIterator<Integer> li = codesUtiles.listIterator();
 			for (ETypeEvent valeur : ETypeEvent.values()) {
 				igm.put(auxMap,li.next(),valeur);				
 			}
 		}
         codesEvenement = auxMap;
     }
 	
 	private CodesEvent() {}
	

}
