package GenerationJSON.ScratchBlocks.Events;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.TreeMap;

import org.apache.commons.lang3.mutable.MutableInt;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import GenerationJSON.Outils.CategoriesBlocs;
import GenerationJSON.Outils.EFamilleEntite;
import GenerationJSON.Outils.ETypeBlocks;
import GenerationJSON.Outils.Entite;
import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.ScratchBlocks.Variable;
import GenerationJSON.ScratchBlocks.Motion.CodesMotion;

public class WhenGreater extends DebutAlgo{

	private ETypeEvent menu= ETypeEvent.Chronometre;
	
	public WhenGreater() {
		super("event_whengreaterthan");
		
		nombreInputs = 1;
		String[] setInputTitles = new String[] {"VALUE"};
		String[] setFieldTitles = new String[] {"WHENGREATERTHANMENU"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		fieldTitles = new ArrayList<String> (Arrays.asList(setFieldTitles));
		simpleInput.put(1, "10");
		simpleInput.put(2, menu.getName());
	}
	@Override
	public JsonNode genereInput() {
		ObjectMapper mapper = new ObjectMapper();
		JsonNode dataNode = mapper.createObjectNode();
		JsonNode inputNode = mapper.createObjectNode();
		Integer indexInputs = 1;
		ListIterator<String> li = inputTitles.listIterator();
		while (li.hasNext()) {
			String inputName = li.next();
			if (blockInput.get(indexInputs)!=null) {
				if (blockInput.get(indexInputs) instanceof Variable) {
					String json = "{\r\n" + 
							"            \""+inputName+"\": [\r\n" + 
							"              3,\r\n" + 
							"              [\r\n" + 
							"                12,\r\n" + 
							"                \""+blockInput.get(indexInputs).getId()+"\",\r\n" + 
							"                \""+blockInput.get(indexInputs).getId()+"\"\r\n" + 
							"              ],\r\n" +
							"              [\r\n" + 
							"                4,\r\n" + 
							"                \""+simpleInput.get(indexInputs)+"\"\r\n" + 
							"              ]\r\n" + 
							"            ]\r\n" + 
							"          }";
					try {
						((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
						((ObjectNode) inputNode).put("inputs", dataNode);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}else {
				String json = "{\r\n" + 
						"            \""+inputName+"\": [\r\n" + 
						"              3,\r\n" + 
						"              \""+blockInput.get(indexInputs).getId()+"\",\r\n" + 
						"              [\r\n" + 
						"                4,\r\n" + 
						"                \""+simpleInput.get(indexInputs)+"\"\r\n" + 
						"              ]\r\n" + 
						"            ]\r\n" + 
						"          }";
				try {
					((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
					((ObjectNode) inputNode).put("inputs", dataNode);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}}
				
			else {
				String json = "{\r\n" + 
						"            \""+inputName+"\": [\r\n" + 
						"              1,\r\n" + 
						"              [\r\n" + 
						"                4,\r\n" + 
						"                \""+simpleInput.get(indexInputs)+"\"\r\n" + 
						"              ]\r\n" + 
						"            ]\r\n" + 
						"          }";
					
				try {
					((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
					((ObjectNode) inputNode).put("inputs", dataNode);
						//rootNode.put(Blockinput);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				indexInputs++;
				}
		
			
		
		
		
			
		return dataNode;
		}
	
	@Override
	public JsonNode genereField() {
			ObjectMapper mapper = new ObjectMapper();
			JsonNode dataNode = mapper.createObjectNode();
			JsonNode fieldNode = mapper.createObjectNode();
			ListIterator<String> li = fieldTitles.listIterator();
			Integer indexFields = 2;
			while (li.hasNext()) {
				String fieldName = li.next();
				String json = "{\r\n" + 
							"						\""+fieldName+"\": [\r\n" + 
							"							\""+simpleInput.get(indexFields)+"\"\r\n" + 
							"						]\r\n" + 
							"					}";
					try {
						((ObjectNode) dataNode).put(fieldName,mapper.readTree(json).get(fieldName));
						((ObjectNode) fieldNode).put("fields", dataNode);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					 indexFields++;
					}
					
					return dataNode;
				   
					}
	

	
	
	@Override
	public boolean ajoutInputsBloc(LinkedList<Entite> programme, LinkedList<Variable> variables, MutableInt indexEntrees, LinkedList<TreeMap<Integer, ETypeBlocks>> associations,LinkedList<Block> algorithme) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
		TreeMap<Integer, ETypeBlocks> association = associations.get(0);
		Entite entree;
		if (indexEntrees.getValue()>=programme.size()-1) {
			System.out.println("Fin de l'algorithme !!!");
			return false;
		}
		indexEntrees.add(1);
		entree = programme.get(indexEntrees.getValue());
		if (entree.getType() == EFamilleEntite.TopCode) {
			if (CodesEvent.codesEvenement.containsKey(Integer.valueOf(entree.getValeur()))) {
				menu = CodesEvent.codesEvenement.get(Integer.valueOf(entree.getValeur()));
				simpleInput.put(2, menu.getName());
			}else {
				System.out.println("Inconsistance");
				return false;
			}
		}else {
			System.out.println("Inconsistance");
			return false;			
		}
		if (indexEntrees.getValue()>=programme.size()-1) {
			System.out.println("Fin de l'algorithme !!!");
			return false;
		}
		Integer inputKey = 1;
		while (inputKey<=nombreInputs && indexEntrees.getValue()<programme.size()-1) {
			association = associations.get(0);
			System.out.println("index Entee jb " + indexEntrees);
			System.out.println("inputkey = " +inputKey);
			indexEntrees.add(1);
			entree = programme.get(indexEntrees.getValue());
			System.out.println(entree);
			
			if (entree.getType() == EFamilleEntite.TopCode) {
				System.out.println("jb est par ci");
				
				if (association.get(Integer.valueOf(entree.getValeur())) == ETypeBlocks.NouveauxBlocs) {
					
					if (indexEntrees.getValue()>= programme.size()-1) {
						System.out.println("Algorithme terminé !!!!");
						return false;
					}						
					indexEntrees.add(1);
				    entree = programme.get(indexEntrees.getValue());
				    association = associations.get(1);
					
				}
				
					
					if (!CategoriesBlocs.nonInstanciables.contains(association.get(Integer.valueOf(entree.getValeur())))) {
					Class<?> cls = Class.forName(association.get(Integer.valueOf(entree.getValeur())).getName());
					Block block = (Block) cls.newInstance();
					Method method = cls.getMethod("setParent",String.class);
					method.invoke(block, getId());
					method = cls.getMethod("ajoutInputsBloc",LinkedList.class, LinkedList.class, MutableInt.class,LinkedList.class, LinkedList.class );
					System.out.println(block);
					method.invoke(block,programme,variables, indexEntrees,associations, algorithme);
					System.out.println("azaz");
					blockInput.put(inputKey, block);
					if (block.getClass() == Variable.class) {
						variables.add((Variable) block);
					}
					else {
						algorithme.add(block);
					}						
					}
					else {
						System.out.println("Oh c'est non instanciable !!!!!");
						return false;
					}
					
				
				
				
			}
			else {
				System.out.println("jb est par là");
				simpleInput.put(inputKey, entree.getValeur());

			
				
			}
			

			System.out.println(inputKey + "lalala");
			inputKey++;
			
			System.out.println(inputKey + "ppppa");
			System.out.println(inputKey<=nombreInputs && indexEntrees.getValue()<programme.size()-1);
			
		}
		return true;
		
			
			
			
			
		}

}
