package GenerationJSON.ScratchBlocks.Motion;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;

public class TurnRight extends Block{
	
	public TurnRight() {
		super("motion_turnright");
		nombreInputs = 1;
		String[] setInputTitles = new String[] {"DEGREES"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "15");
		
	}

}
