package GenerationJSON.ScratchBlocks.Motion;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;

public class Bounce extends Block{
	
	public Bounce() {
		super("motion_ifonedgebounce");
		
	}

}
