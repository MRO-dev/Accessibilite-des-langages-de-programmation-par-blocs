package GenerationJSON.ScratchBlocks.Motion;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.TreeMap;

import org.apache.commons.lang3.mutable.MutableInt;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import GenerationJSON.Outils.EFamilleEntite;
import GenerationJSON.Outils.ETypeBlocks;
import GenerationJSON.Outils.Entite;
import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.ScratchBlocks.Variable;
/**
 * Classe mod�lisant le menu d�roulant pour le bloc "GoTo"
 * @author Jean-Baptiste
 *
 */
public class GoToMenu extends Block{

	public GoToMenu() {
		super("motion_goto_menu");
		nombreInputs = 0;
		nombreFields = 1;
		isInputVariable = true;
		String[] setFieldTitles = new String[] {"TO"};
		fieldTitles = new ArrayList<String> (Arrays.asList(setFieldTitles));
		fields.put(1, "_random_");
	}
	

	@Override
	public JsonNode genereField() {
			ObjectMapper mapper = new ObjectMapper();
			JsonNode dataNode = mapper.createObjectNode();
			JsonNode fieldNode = mapper.createObjectNode();
			ListIterator<String> li = fieldTitles.listIterator();
			Integer indexFields = 1;
			while (li.hasNext()) {
				String fieldName = li.next();
				String json = "{\r\n" + 
							"						\""+fieldName+"\": [\r\n" + 
							"							\""+fields.get(indexFields)+"\"\r\n" + 
							"						]\r\n" + 
							"					}";
					try {
						((ObjectNode) dataNode).put(fieldName,mapper.readTree(json).get(fieldName));
						((ObjectNode) fieldNode).put("fields", dataNode);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					 indexFields++;
					}
					
					return dataNode;
				   
					}
	@Override
	public boolean ajoutInputsBloc(LinkedList<Entite> programme, LinkedList<Variable> variables, MutableInt indexEntrees, LinkedList<TreeMap<Integer, ETypeBlocks>> association,LinkedList<Block> algorithme) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
		Entite entree;
		if (indexEntrees.getValue()>=programme.size()-1) {
			System.out.println("Fin de l'algorithme !!!");
			return false;
		}
		indexEntrees.add(1);
		entree = programme.get(indexEntrees.getValue());
		if (entree.getType() == EFamilleEntite.TopCode) {
			if (CodesMotion.codesPositions.containsKey(Integer.valueOf(entree.getValeur()))) {
				fields.put(1, CodesMotion.codesPositions.get(Integer.valueOf(entree.getValeur())).getName());
				return true;
			}else {
				System.out.println("Inconsistance !!!");
				return false;
			}
		}else {
			System.out.println("Inconsistance !!!");
			return false;
		}
		
			
			
			
			
		}
	

}
