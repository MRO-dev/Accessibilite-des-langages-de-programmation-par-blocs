package GenerationJSON.ScratchBlocks.Motion;

import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.ScratchBlocks.VariableEntreeBloc;

public class Direction extends VariableEntreeBloc{

	public Direction() {
		super("motion_direction");
		// TODO Auto-generated constructor stub
	}


}
