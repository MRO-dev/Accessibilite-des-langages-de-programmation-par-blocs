package GenerationJSON.ScratchBlocks.Motion;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;

public class ChangeX extends Block {
	
	
	public ChangeX() {
		super("motion_changexby");
		nombreInputs = 1;
		String[] setInputTitles = new String[] {"DX"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "10");
	}

}
