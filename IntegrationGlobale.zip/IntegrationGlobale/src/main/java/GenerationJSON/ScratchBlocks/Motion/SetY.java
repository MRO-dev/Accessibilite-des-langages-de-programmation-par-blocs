package GenerationJSON.ScratchBlocks.Motion;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;

public class SetY extends Block{


	public SetY() {
		
		super("motion_sety");
		nombreInputs = 1;
		String[] setInputTitles = new String[] {"Y"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "0");
	}
	
}
