package GenerationJSON.ScratchBlocks.Motion;

import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.ScratchBlocks.VariableEntreeBloc;

public class PositionX extends VariableEntreeBloc{

	public PositionX() {
		super("motion_xposition");
		// TODO Auto-generated constructor stub
	}



}
