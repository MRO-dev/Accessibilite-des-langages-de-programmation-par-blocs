package GenerationJSON.ScratchBlocks.Motion;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;

public class GlideToXY extends Block  {

	public GlideToXY() {
		super("motion_glidesecstoxy");
		nombreInputs = 3;
		String[] setInputTitles = new String[] {"SECS","X", "Y"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "1");
		simpleInput.put(2, "0");
		simpleInput.put(3, "0");
	}

}
