/**
 * Package mod�lisant l'ensemble des blocs de mouvement Scratch.
 * @author Jean-Baptiste Marco
 */

package GenerationJSON.ScratchBlocks.Motion;