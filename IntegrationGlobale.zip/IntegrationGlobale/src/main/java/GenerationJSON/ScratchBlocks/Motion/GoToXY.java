package GenerationJSON.ScratchBlocks.Motion;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;

public class GoToXY extends Block{
	

	public GoToXY() {
		super("motion_gotoxy");
		nombreInputs = 2;
		String[] setInputTitles = new String[] {"X", "Y"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "0");
		simpleInput.put(2, "0");
	}
	



	
}
