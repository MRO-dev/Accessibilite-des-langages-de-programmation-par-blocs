package GenerationJSON.ScratchBlocks.Motion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.ListIterator;
import java.util.TreeMap;
import java.util.TreeSet;

import GenerationJSON.Outils.ETypeBlocks;
import GenerationJSON.Outils.InsertionGeneriqueMap;

/**
 * Classe associant � chaque type de position un code sp�cifique
 * @author Jean-Baptiste
 *
 */
public class CodesMotion {
	
	private static final Integer[] SET_VALUES = new Integer[] {31, 47};
	private static final TreeSet<Integer> monTreeSet = new TreeSet<Integer>(Arrays.asList(SET_VALUES));
	private static final ArrayList<Integer> codesUtiles = new ArrayList<Integer>(monTreeSet);
	private static InsertionGeneriqueMap<Integer, ETypePosition, TreeMap<Integer,ETypePosition>> igm = new InsertionGeneriqueMap<Integer, ETypePosition, TreeMap<Integer,ETypePosition>>();
 	public static final TreeMap<Integer, ETypePosition> codesPositions;
 	static {
 		 TreeMap<Integer, ETypePosition> auxMap = new TreeMap<Integer,ETypePosition>();
         TreeSet<Integer> monTreeSet = new TreeSet<Integer>(Arrays.asList(SET_VALUES));
 		 ArrayList<Integer> codesUtiles = new ArrayList<Integer>(monTreeSet);
 		 if (codesUtiles.size()!= ETypePosition.values().length) {
 			System.out.println("Inconsistance des entr�es");
 		 }
 		 else {
 			ListIterator<Integer> li = codesUtiles.listIterator();
 			for (ETypePosition valeur : ETypePosition.values()) {
 				igm.put(auxMap,li.next(),valeur);				
 			}
 		}
         codesPositions = auxMap;
     }
 	
 	private CodesMotion() {}
 	
 	
 	

}
