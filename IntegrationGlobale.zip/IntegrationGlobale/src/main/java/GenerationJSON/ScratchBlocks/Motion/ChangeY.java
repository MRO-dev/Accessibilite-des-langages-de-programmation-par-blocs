package GenerationJSON.ScratchBlocks.Motion;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;

public class ChangeY extends Block{
	
	public ChangeY() {
		super("motion_changeyby");
		nombreInputs = 1;
		String[] setInputTitles = new String[] {"DY"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "10");
	}


	
}
