package GenerationJSON.ScratchBlocks.Motion;

/**
 * Enum�ration des diff�rents types de position : Random et Souris
 * @author Jean-Baptiste
 *
 */
public enum ETypePosition {

	Aleatoire ("_random_"), Souris ("_mouse_");
	
	
	
	private String name;
	
	
	
	private ETypePosition(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
