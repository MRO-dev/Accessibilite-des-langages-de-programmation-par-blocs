package GenerationJSON.ScratchBlocks.Motion;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;

public class SetX extends Block{
	
	
	
	public SetX() {
		super("motion_setx");
		nombreInputs = 1;
		String[] setInputTitles = new String[] {"X"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "0");
	}
	
}
