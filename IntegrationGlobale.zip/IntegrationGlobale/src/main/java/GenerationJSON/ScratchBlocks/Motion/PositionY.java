package GenerationJSON.ScratchBlocks.Motion;

import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.ScratchBlocks.VariableEntreeBloc;

public class PositionY extends VariableEntreeBloc{

	public PositionY() {
		super("motion_yposition");
		// TODO Auto-generated constructor stub
	}

	
}
