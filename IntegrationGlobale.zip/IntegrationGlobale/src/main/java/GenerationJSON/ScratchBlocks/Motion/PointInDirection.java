package GenerationJSON.ScratchBlocks.Motion;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;

public class PointInDirection extends Block{
	
	public PointInDirection() {
		super("motion_pointindirection");
		nombreInputs = 1;
		String[] setInputTitles = new String[] {"DIRECTION"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "90");
	}


}
