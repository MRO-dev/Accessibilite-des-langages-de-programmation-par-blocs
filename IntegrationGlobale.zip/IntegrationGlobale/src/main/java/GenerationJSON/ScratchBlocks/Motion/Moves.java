package GenerationJSON.ScratchBlocks.Motion;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;

public class Moves extends Block {
	
	
	public Moves() {
		super("motion_movesteps");
		nombreInputs = 1;
		String[] setInputTitles = new String[] {"STEPS"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "10");
	}
	
	

//	public void traiteTopCode(ArrayList<Integer> codes, int indexCodes, ArrayList<Integer> inputs, int indexInputs, TreeMap<Integer, ETypeBlocks> association) {
//		
//		if (CategoriesBlocs.operationsElementairesUnaires.contains(association.get(codes.get(indexCodes)))) {
//			blockInput = new Addition();
//			setNext(blockInput.getId())
//			JsonNode rootNode = traduitCode();
//			
//			}
//		// TODO Auto-generated method stub
//		
//	}

	/*public JsonNode traduitCode() {
		ObjectMapper mapper = new ObjectMapper();
		JsonNode rootNode = mapper.createObjectNode();

		JsonNode childNode = mapper.createObjectNode();
		((ObjectNode) childNode).put("opcode","motion_movesteps");
		((ObjectNode) childNode).putNull("next");
		((ObjectNode) childNode).putNull("parent");
		((ObjectNode) childNode).put("inputs", "val2");
		JsonNode stepsNode = mapper.createObjectNode();
		String json = "{\"STEPS\": [\r\n" + 
			 		"              1,\r\n" + 
			 		"              [\r\n" + 
			 		"                4,\r\n" + 
			 		"                \"10\"\r\n" + 
			 		"              ]\r\n" + 
			 		"            ]}";
		try {
			((ObjectNode) stepsNode).put("STEPS",mapper.readTree(json).get("STEPS"));
			((ObjectNode) childNode).put("inputs", stepsNode);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		((ObjectNode) childNode).put("fields", mapper.createObjectNode());
		((ObjectNode) childNode).put("topLevel", true);
		((ObjectNode) childNode).put("shadow", false);
		((ObjectNode) childNode).put("x", 10);
		((ObjectNode) childNode).put("y", 10);
		((ObjectNode) rootNode).put("BlocNumero"+getNumero(), childNode);
		String jsonString;
		try {
			
			jsonString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(rootNode);
			System.out.println(jsonString);
			
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return rootNode;
	}*/
	
}
