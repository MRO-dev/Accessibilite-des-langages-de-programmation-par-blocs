package GenerationJSON.ScratchBlocks.Control;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import GenerationJSON.Outils.ETypeBlocks;
import GenerationJSON.ScratchBlocks.Variable;

public class Repeat extends ControleStructure {
	
	public Repeat() {
		super("control_repeat");
		taille = 135;
		nombreInputs = 1;
		nombreStructures = 1;
		String[] setInputTitles = new String[] {"TIMES", "SUBSTACK"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "10");
		setDebutStruct(ETypeBlocks.RepeatBegin);
		setFinStruct(ETypeBlocks.RepeatEnd);
	}
	
	@Override
	public JsonNode genereInput() {
		ObjectMapper mapper = new ObjectMapper();
		JsonNode dataNode = mapper.createObjectNode();
		JsonNode inputNode = mapper.createObjectNode();
		Integer inputsKey = 1;
		Integer structKey = 1;
		Integer indexTitles = 0;
		String inputName = inputTitles.get(indexTitles);
		if (blockInput.get(inputsKey)!=null) {
			if (blockInput.get(inputsKey) instanceof Variable) {
				String json = "{\r\n" + 
						"            \""+inputName+"\": [\r\n" + 
						"              3,\r\n" + 
						"              [\r\n" + 
						"                12,\r\n" + 
						"                \""+blockInput.get(inputsKey).getId()+"\",\r\n" + 
						"                \""+blockInput.get(inputsKey).getId()+"\"\r\n" + 
						"              ],\r\n" +
						"              [\r\n" + 
						"                4,\r\n" + 
						"                \""+simpleInput.get(inputsKey)+"\"\r\n" + 
						"              ]\r\n" + 
						"            ]\r\n" + 
						"          }";
				try {
					((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
					((ObjectNode) inputNode).put("inputs", dataNode);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}else {
			
			String json = "{\r\n" + 
					"						\""+inputName+"\": [\r\n" + 
					"							3,\r\n" + 
					"							\""+blockInput.get(inputsKey).getId()+"\",\r\n" + 
					"							[\r\n" + 
					"								6,\r\n" + 
					"								\"10\"\r\n" + 
					"							]\r\n" + 
					"						]\r\n" + 
					"					}";
			try {
				((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
				((ObjectNode) inputNode).put("inputs", dataNode);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}}
		
		else {
			String json = "{\r\n" + 
					"            \""+inputName+"\": [\r\n" + 
					"              1,\r\n" +  
					"              [\r\n" + 
					"                6,\r\n" + 
					"                \""+simpleInput.get(inputsKey)+"\"\r\n" + 
					"              ]\r\n" + 
					"            ]\r\n" + 
					"          }";
			
			try {
				((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
				((ObjectNode) inputNode).put("inputs", dataNode);
				//rootNode.put(Blockinput);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			inputsKey++;
			indexTitles++;
			while (structKey <= nombreStructures && indexTitles < inputTitles.size()) {
			inputName = inputTitles.get(indexTitles);
			
			if (blockInput.get(inputsKey)!=null) {
				String json = "{"
						+ "\""+inputName+"\": [\r\n" + 
						"							2,\r\n" + 
						"							\""+blockInput.get(inputsKey).getId()+"\"\r\n" + 
						"						]"
						+ "}";
				
			try {
					((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
					((ObjectNode) inputNode).put("inputs", dataNode);
					//rootNode.put(Blockinput);
			} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			structKey++;
			indexTitles++;
			}

		
		return dataNode;
	}


	
	
}
