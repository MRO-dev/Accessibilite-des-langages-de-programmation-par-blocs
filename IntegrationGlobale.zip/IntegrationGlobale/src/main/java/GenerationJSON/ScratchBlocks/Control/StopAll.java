package GenerationJSON.ScratchBlocks.Control;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ListIterator;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import GenerationJSON.ScratchBlocks.Block;

public class StopAll extends Block{

	public StopAll() {
		super("control_stop");
		nombreInputs = 0;
		nombreFields = 1;
		String[] setFieldTitles = new String[] {"STOP_OPTION"};
		fieldTitles = new ArrayList<String> (Arrays.asList(setFieldTitles));
		fields.put(1, "all");
		
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public JsonNode genereField() {
			ObjectMapper mapper = new ObjectMapper();
			JsonNode dataNode = mapper.createObjectNode();
			JsonNode fieldNode = mapper.createObjectNode();
			ListIterator<String> li = fieldTitles.listIterator();
			Integer indexFields = 1;
			while (li.hasNext()) {
				String fieldName = li.next();
				String json = "{\r\n" + 
							"						\""+fieldName+"\": [\r\n" + 
							"							\""+fields.get(indexFields)+"\"\r\n" + 
							"						]\r\n" + 
							"					}";
					try {
						((ObjectNode) dataNode).put(fieldName,mapper.readTree(json).get(fieldName));
						((ObjectNode) fieldNode).put("fields", dataNode);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					 indexFields++;
					}
					
					return dataNode;
				   
					}
				
			
			

		}


