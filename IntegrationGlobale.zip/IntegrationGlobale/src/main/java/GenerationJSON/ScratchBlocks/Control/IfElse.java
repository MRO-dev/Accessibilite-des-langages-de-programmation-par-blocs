package GenerationJSON.ScratchBlocks.Control;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.TreeMap;

import org.apache.commons.lang3.mutable.MutableInt;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import GenerationJSON.Outils.ETypeBlocks;
import GenerationJSON.Outils.Entite;
import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.ScratchBlocks.Variable;
import GenerationJSON.Outils.EFamilleEntite;

public class IfElse extends ControleStructure {
	
	private static ETypeBlocks finIntermediaire = ETypeBlocks.IfElseIfEnd;
	private static LinkedList<ETypeBlocks> finsStatement;

	public IfElse() {
		super("control_if_else");
		taille = 185;
		nombreInputs = 1;
		nombreStructures = 2;
		String[] setInputTitles = new String[] {"CONDITION", "SUBSTACK", "SUBSTACK2"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		setDebutStruct(ETypeBlocks.IfElseBegin);
		setFinStruct(ETypeBlocks.IfElseEnd);
		ETypeBlocks[] SET_FINS = new ETypeBlocks[] {finIntermediaire,getFinStruct()};
		finsStatement = new LinkedList<ETypeBlocks>(Arrays.asList(SET_FINS));
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public JsonNode genereInput() {
		ObjectMapper mapper = new ObjectMapper();
		JsonNode dataNode = mapper.createObjectNode();
		JsonNode inputNode = mapper.createObjectNode();
		Integer inputsKey = 1;
		Integer structKey = 1;
		Integer indexTitles = 0;
		String inputName = inputTitles.get(indexTitles);
		if (blockInput.get(inputsKey)!=null) {
			String json = "{"
					+ "\""+inputName+"\": [\r\n" + 
					"							2,\r\n" + 
					"							\""+blockInput.get(inputsKey).getId()+"\"\r\n" + 
					"						]"
					+ "}";
			
		try {
				((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
				((ObjectNode) inputNode).put("inputs", dataNode);
				//rootNode.put(Blockinput);
		} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			inputsKey++;
			indexTitles++;
			while (structKey <= nombreStructures && indexTitles < inputTitles.size()) {
			inputName = inputTitles.get(indexTitles);
			
			if (blockInput.get(inputsKey)!=null) {
				String json = "{"
						+ "\""+inputName+"\": [\r\n" + 
						"							2,\r\n" + 
						"							\""+blockInput.get(inputsKey).getId()+"\"\r\n" + 
						"						]"
						+ "}";
				
			try {
					((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
					((ObjectNode) inputNode).put("inputs", dataNode);
					//rootNode.put(Blockinput);
			} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			inputsKey++;
			structKey++;
			indexTitles++;
			}

		
		return dataNode;
	}


	
	@Override
	public boolean ajoutInputsBloc(LinkedList<Entite> programme,LinkedList<Variable> variables, MutableInt indexEntrees,
			LinkedList<TreeMap<Integer, ETypeBlocks>> associations,LinkedList<Block> algorithme)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException,
			SecurityException, IllegalArgumentException, InvocationTargetException {
		TreeMap<Integer, ETypeBlocks> association = associations.get(0);
		Integer inputKey = 1;
		Integer compteurInputs = 1;
		Integer structKey = 1;
//		Integer indexInputs = 0;
		boolean isInputBlock = true;
		Entite entree;
//		boolean isOperator = true;
		while (inputKey<=nombreInputs && indexEntrees.getValue()<programme.size()-1) {
			association = associations.get(0);
			indexEntrees.add(1);
			entree = programme.get(indexEntrees.getValue());
			System.out.println(entree);
					if (entree.getType() == EFamilleEntite.TopCode) {
						if (association.get(Integer.valueOf(entree.getValeur())) == ETypeBlocks.NouveauxBlocs) {
							
							if (indexEntrees.getValue()>= programme.size()-1) {
								System.out.println("Algorithme terminé !!!!");
								return false;
							}						
							indexEntrees.add(1);
						    entree = programme.get(indexEntrees.getValue());
						    association = associations.get(1);
							
						}
						Class<?> cls = Class.forName(association.get(Integer.valueOf(entree.getValeur())).getName());
						Block block = (Block) cls.newInstance();
						Method method = cls.getMethod("setParent",String.class);
						method.invoke(block, getId());
						method = cls.getMethod("ajoutInputsBloc",LinkedList.class,LinkedList.class,MutableInt.class,LinkedList.class, LinkedList.class);
						System.out.println("Invocation TopCode");
						method.invoke(block,programme,variables,indexEntrees,associations, algorithme);
						blockInput.put(inputKey, block);
						if (block.getClass() == Variable.class) {
//							variables.add((Variable) block);
						}
						else {
							algorithme.add(block);
						}						
						isInputBlock = false;
						inputKey++;
						
						
					}
					else {
						simpleInput.put(inputKey, entree.getValeur());
						compteurInputs--;
						isInputBlock = false;
						inputKey++;
						
					}
					
				}
						
		
		
		System.out.println("InputKey de la boucle = " + inputKey);
		int indexFinStatements =0;
		association = associations.get(0);
		while (structKey <= nombreStructures && indexFinStatements < finsStatement.size()) {
			association = associations.get(0);
			System.out.println("Entree Boucle lll");
			System.out.println("MrF");
				System.out.println("MrF");
				indexEntrees.add(1);
				entree = programme.get(indexEntrees.getValue());
			ETypeBlocks finInstructions = finsStatement.get(indexFinStatements); 
					if (entree.getType() == EFamilleEntite.TopCode) {
						System.out.println("Rutabaga");
						if (association.get(Integer.valueOf(entree.getValeur())) == finInstructions) {
							structKey++;
						}
						else {
							if (association.get(Integer.valueOf(entree.getValeur())) == ETypeBlocks.NouveauxBlocs) {
								
								if (indexEntrees.getValue()>= programme.size()-1) {
									System.out.println("Algorithme terminé !!!!");
									return false;
								}						
								indexEntrees.add(1);
							    entree = programme.get(indexEntrees.getValue());
							    association = associations.get(1);
								
							}
							System.out.println("instanciation sous block");
							Class<?> cls = Class.forName(association.get(Integer.valueOf(entree.getValeur())).getName());
							Block block = (Block) cls.newInstance();
							System.out.println(block);
							Method method = cls.getMethod("setParent",String.class);
							method.invoke(block, getId());
							System.out.println(indexFinStatements);
							System.out.println(finsStatement);
							System.out.println(finInstructions);
							traiteSousBloc(programme,variables, indexEntrees,block, associations, algorithme, getDebutStruct(), finInstructions, inputKey);
							
							isInputBlock = false;
							compteurInputs--;
							System.out.println(compteurInputs);
						}
						
						
						
					}
					else {
						System.out.println("Inconsistance des données");
//						simpleInput.put(inputKey, entree.getValeur());
//						inputKey ++;
//						compteurInputs--;
//						isInputBlock = false;
						
					}
					structKey++;
					inputKey++;
					indexFinStatements++;
				}
				
			
			
			
			
		return true;
		
		
	}

	
//	@Override
//	public JsonNode genereInput() {
//		ObjectMapper mapper = new ObjectMapper();
//		JsonNode dataNode = mapper.createObjectNode();
//		JsonNode inputNode = mapper.createObjectNode();
//		if (blockInput!=null) {
//			String json = "{\r\n" + 
//					"            \"CONDITION\": [\r\n" + 
//					"              3,\r\n" + 
//					"              \""+blockInput.getId()+"\",\r\n" + 
//					"              [\r\n" + 
//					"                4,\r\n" + 
//					"                \""+input+"\"\r\n" + 
//					"              ]\r\n" + 
//					"            ]\r\n" + 
//					"          }";
//			
//			try {
//				((ObjectNode) dataNode).put("CONDITION",mapper.readTree(json).get("CONDITION"));
//				((ObjectNode) inputNode).put("inputs", dataNode);
//				//rootNode.put(Blockinput);
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//		else {
//			String json = "{\r\n" + 
//					"            \"CONDITION\": [\r\n" + 
//					"              1,\r\n" + 
//					"              [\r\n" + 
//					"                4,\r\n" + 
//					"                \""+input+"\"\r\n" + 
//					"              ]\r\n" + 
//					"            ]\r\n" + 
//					"          }";
//			try {
//				((ObjectNode) dataNode).put("CONDITION",mapper.readTree(json).get("CONDITION"));
//				((ObjectNode) inputNode).put("inputs", dataNode);
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//		
//		// TODO Auto-generated method stub
//		return inputNode;
//	}
//	
//	public Block genereBlocSuivant(ArrayList<Integer> codes, Integer indexCodes, TreeMap<Integer, ETypeBlocks> association) {
//		int iBlocSuivant = indexCodes+1;
//		int compteurStructure = 1;
//		while (iBlocSuivant < codes.size() && compteurStructure >1) {
//			if (association.get(codes.get(iBlocSuivant))==ETypeBlocks.IfElseEnd ) {
//				compteurStructure--;
//			}
//			iBlocSuivant++;
//				
//		}
//		if (iBlocSuivant>=codes.size()|| CategoriesBlocs.nonInstanciables.contains(association.get(codes.get(iBlocSuivant)))) {
//			return null;
//		}
//		else {
//			//A implementer
//		}
//		return null;
//		
//	}



}
