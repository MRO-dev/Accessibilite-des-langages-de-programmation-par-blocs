package GenerationJSON.ScratchBlocks.Control;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ListIterator;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import GenerationJSON.ScratchBlocks.Block;

public class Wait extends Block{
	
	public Wait() {
		super("control_wait");
		nombreInputs = 1;
		String[] setInputTitles = new String[] {"DURATION"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "1");
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public JsonNode genereInput() {
		if (nombreInputs == 0) {
			return null;
		}
		else {  
			ObjectMapper mapper = new ObjectMapper();
			JsonNode dataNode = mapper.createObjectNode();
			JsonNode inputNode = mapper.createObjectNode();
			Integer indexInputs = 1;
			ListIterator<String> li = inputTitles.listIterator();
			while (li.hasNext()) {
				String inputName = li.next();
				if (blockInput.get(indexInputs)!=null) {
					String json = "{\r\n" + 
							"            \""+inputName+"\": [\r\n" + 
							"              3,\r\n" + 
							"              \""+blockInput.get(indexInputs).getId()+"\",\r\n" + 
							"              [\r\n" + 
							"                5,\r\n" + 
							"                \""+simpleInput.get(indexInputs)+"\"\r\n" + 
							"              ]\r\n" + 
							"            ]\r\n" + 
							"          }";
					try {
						((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
						((ObjectNode) inputNode).put("inputs", dataNode);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
				else {
					String json = "{\r\n" + 
							"            \""+inputName+"\": [\r\n" + 
							"              1,\r\n" + 
							"              [\r\n" + 
							"                5,\r\n" + 
							"                \""+simpleInput.get(indexInputs)+"\"\r\n" + 
							"              ]\r\n" + 
							"            ]\r\n" + 
							"          }";
						
					try {
						((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
						((ObjectNode) inputNode).put("inputs", dataNode);
							//rootNode.put(Blockinput);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					indexInputs++;
					}
				
			return dataNode;
			}

		}
	

}
