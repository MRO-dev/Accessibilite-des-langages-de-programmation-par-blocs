package GenerationJSON.ScratchBlocks.Control;

import GenerationJSON.ScratchBlocks.Block;

public class SupprimeClone extends Block{

	public SupprimeClone() {
		super("control_delete_this_clone");
		// TODO Auto-generated constructor stub
	}

}
