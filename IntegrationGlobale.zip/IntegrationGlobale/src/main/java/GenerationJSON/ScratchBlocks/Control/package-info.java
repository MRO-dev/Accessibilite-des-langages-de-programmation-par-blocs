/**
 * Package mod�lisant l'ensemble des structures de Controle Scratch.
 * @author Jean-Baptiste Marco
 */

package GenerationJSON.ScratchBlocks.Control;