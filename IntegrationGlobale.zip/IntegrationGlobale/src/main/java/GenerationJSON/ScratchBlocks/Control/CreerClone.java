package GenerationJSON.ScratchBlocks.Control;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.TreeMap;

import org.apache.commons.lang3.mutable.MutableInt;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import GenerationJSON.Outils.EFamilleEntite;
import GenerationJSON.Outils.ETypeBlocks;
import GenerationJSON.Outils.Entite;
import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.ScratchBlocks.Variable;
import GenerationJSON.ScratchBlocks.Musique.MenuInstrument;

public class CreerClone extends Block{

	public CreerClone() {
		super("control_create_clone_of");
		nombreInputs = 0;
		String[] setInputTitles = new String[] {"CLONE_OPTION"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		Block cloneMenu = new CloneMenu();
		cloneMenu.setParent(getId());
		blockInput.put(1, cloneMenu);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public JsonNode genereInput() {
		JsonNode dataNode;
		JsonNode inputNode;
	
		
			ObjectMapper mapper = new ObjectMapper();
			dataNode = mapper.createObjectNode();
			inputNode = mapper.createObjectNode();
			Integer indexInputs = 1;
			ListIterator<String> li = inputTitles.listIterator();
			while (li.hasNext()) {
				String inputName = li.next();
				if (blockInput.get(indexInputs)!=null) {
					String json = "{\r\n" + 
							"						\""+inputName+"\": [\r\n" + 
							"							1,\r\n" + 
							"							\""+blockInput.get(indexInputs).getId()+"\"\r\n" + 
							"						]\r\n" + 
							"					}";
					try {
						((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
						((ObjectNode) inputNode).put("inputs", dataNode);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
				else {
//					String json = "{\r\n" + 
//							"            \""+inputName+"\": [\r\n" + 
//							"              1,\r\n" + 
//							"              [\r\n" + 
//							"                4,\r\n" + 
//							"                \""+simpleInput.get(indexInputs)+"\"\r\n" + 
//							"              ]\r\n" + 
//							"            ]\r\n" + 
//							"          }";
//						
//					try {
//						((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
//						((ObjectNode) inputNode).put("inputs", dataNode);
//							//rootNode.put(Blockinput);
//						} catch (IOException e) {
//							// TODO Auto-generated catch block
//							e.printStackTrace();
//						}
//					}
//					indexInputs++;
					return null;
					}
				
			
			}

		
		
		
		return dataNode;
	

}
	
	@Override
	public boolean ajoutInputsBloc(LinkedList<Entite> programme, LinkedList<Variable> variables, MutableInt indexEntrees, LinkedList<TreeMap<Integer, ETypeBlocks>> associations,LinkedList<Block> algorithme) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
		Block menu = blockInput.get(1);		
		menu.ajoutInputsBloc(programme, variables, indexEntrees, associations, algorithme);
		blockInput.put(1, menu);
		algorithme.add(menu);
		return true;
			
			
			
			
		}

}
