package GenerationJSON.ScratchBlocks.Control;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import GenerationJSON.Outils.ETypeBlocks;

public class RepeatUntil extends ControleStructure {
	
	public RepeatUntil() {
		super("control_repeat_until");
		taille = 135;
		nombreInputs = 1;
		nombreStructures = 1;
		String[] setInputTitles = new String[] {"CONDITION", "SUBSTACK"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		setDebutStruct(ETypeBlocks.RepeatUntilBegin);
		setFinStruct(ETypeBlocks.RepeatUntilEnd);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public JsonNode genereInput() {
		ObjectMapper mapper = new ObjectMapper();
		JsonNode dataNode = mapper.createObjectNode();
		JsonNode inputNode = mapper.createObjectNode();
		Integer inputsKey = 1;
		Integer structKey = 1;
		Integer indexTitles = 0;
		String inputName = inputTitles.get(indexTitles);
		if (blockInput.get(inputsKey)!=null) {
			String json = "{"
					+ "\""+inputName+"\": [\r\n" + 
					"							2,\r\n" + 
					"							\""+blockInput.get(inputsKey).getId()+"\"\r\n" + 
					"						]"
					+ "}";
			
		try {
				((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
				((ObjectNode) inputNode).put("inputs", dataNode);
				//rootNode.put(Blockinput);
		} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			inputsKey++;
			indexTitles++;
			while (structKey <= nombreStructures && indexTitles < inputTitles.size()) {
			inputName = inputTitles.get(indexTitles);
			
			if (blockInput.get(inputsKey)!=null) {
				String json = "{"
						+ "\""+inputName+"\": [\r\n" + 
						"							2,\r\n" + 
						"							\""+blockInput.get(inputsKey).getId()+"\"\r\n" + 
						"						]"
						+ "}";
				
			try {
					((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
					((ObjectNode) inputNode).put("inputs", dataNode);
					//rootNode.put(Blockinput);
			} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			structKey++;
			indexTitles++;
			}

		
		return dataNode;
	}


	
//	@Override
//	public JsonNode genereInput() {
//		ObjectMapper mapper = new ObjectMapper();
//		JsonNode dataNode = mapper.createObjectNode();
//		JsonNode inputNode = mapper.createObjectNode();
//		if (blockInput!=null) {
//			String json = "{\r\n" + 
//					"            \"CONDITION\": [\r\n" + 
//					"              3,\r\n" + 
//					"              \""+blockInput.getId()+"\",\r\n" + 
//					"              [\r\n" + 
//					"                4,\r\n" + 
//					"                \""+input+"\"\r\n" + 
//					"              ]\r\n" + 
//					"            ]\r\n" + 
//					"          }";
//			
//			try {
//				((ObjectNode) dataNode).put("CONDITION",mapper.readTree(json).get("CONDITION"));
//				((ObjectNode) inputNode).put("inputs", dataNode);
//				//rootNode.put(Blockinput);
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//		else {
//			String json = "{\r\n" + 
//					"            \"CONDITION\": [\r\n" + 
//					"              1,\r\n" + 
//					"              [\r\n" + 
//					"                4,\r\n" + 
//					"                \""+input+"\"\r\n" + 
//					"              ]\r\n" + 
//					"            ]\r\n" + 
//					"          }";
//			try {
//				((ObjectNode) dataNode).put("CONDITION",mapper.readTree(json).get("CONDITION"));
//				((ObjectNode) inputNode).put("inputs", dataNode);
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//		
//		// TODO Auto-generated method stub
//		return inputNode;
//	}
//	
//	public Block genereBlocSuivant(ArrayList<Integer> codes, Integer indexCodes, TreeMap<Integer, ETypeBlocks> association) {
//		int iBlocSuivant = indexCodes+1;
//		int compteurStructure = 1;
//		while (iBlocSuivant < codes.size() && compteurStructure >1) {
//			if (association.get(codes.get(iBlocSuivant))==ETypeBlocks.RepeatUntilEnd ) {
//				compteurStructure--;
//			}
//			iBlocSuivant++;
//				
//		}
//		if (iBlocSuivant>=codes.size()|| CategoriesBlocs.nonInstanciables.contains(association.get(codes.get(iBlocSuivant)))) {
//			return null;
//		}
//		else {
//			//A implementer
//		}
//		return null;
//		
//	}
//

}
