package GenerationJSON.ScratchBlocks.Control;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.TreeMap;

import org.apache.commons.lang3.mutable.MutableInt;

import GenerationJSON.Outils.ETypeBlocks;
import GenerationJSON.Outils.Entite;
import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.ScratchBlocks.Variable;
import GenerationJSON.Outils.EFamilleEntite;

/**
 * Classe ControleStructure mod�lisant les structures it�ratives (boucles) et conditionnelles du langage Scratch
 * 
 * @author Jean-Baptiste
 *
 */
public abstract class ControleStructure extends Block{
	
	//Mod�lise les Blocs qui d�limitent la structure de contr�le
	private ETypeBlocks debutStruct;
	private ETypeBlocks finStruct;
	protected int nombreStructures;

	public ControleStructure(String opcode) {
		super(opcode);
		// TODO Auto-generated constructor stub
	}
	
	



	public ETypeBlocks getDebutStruct() {
		return debutStruct;
	}





	public void setDebutStruct(ETypeBlocks debutStruct) {
		this.debutStruct = debutStruct;
	}





	public ETypeBlocks getFinStruct() {
		return finStruct;
	}





	public void setFinStruct(ETypeBlocks finStruct) {
		this.finStruct = finStruct;
	}





	@Override
	public boolean ajoutInputsBloc(LinkedList<Entite> programme, LinkedList<Variable> variables, MutableInt indexEntrees,
			LinkedList<TreeMap<Integer, ETypeBlocks>> associations,LinkedList<Block> algorithme)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException,
			SecurityException, IllegalArgumentException, InvocationTargetException {
		TreeMap<Integer, ETypeBlocks> association = associations.get(0);
		System.out.println("le debut struct du ajoutInputs " + debutStruct);
		Integer inputKey = 1;
		Integer compteurInputs = 1;
		Integer structKey = 1;
//		Integer indexInputs = 0;
		boolean isInputBlock = true;
		Entite entree;
//		boolean isOperator = true;
		while (inputKey<=nombreInputs && indexEntrees.getValue()<programme.size()-1) {
					association = associations.get(0);
				    indexEntrees.add(1);
					entree = programme.get(indexEntrees.getValue());
					System.out.println(entree);
					if (entree.getType() == EFamilleEntite.TopCode) {
						if (association.get(Integer.valueOf(entree.getValeur())) == ETypeBlocks.NouveauxBlocs) {
							
							if (indexEntrees.getValue()>= programme.size()-1) {
								System.out.println("Algorithme terminé !!!!");
								return false;
							}						
							indexEntrees.add(1);
						    entree = programme.get(indexEntrees.getValue());
						    association = associations.get(1);
							
						}
						Class<?> cls = Class.forName(association.get(Integer.valueOf(entree.getValeur())).getName());
						Block block = (Block) cls.newInstance();
						Method method = cls.getMethod("setParent",String.class);
						method.invoke(block, getId());
						method = cls.getMethod("ajoutInputsBloc",LinkedList.class,LinkedList.class,MutableInt.class,LinkedList.class, LinkedList.class);
						System.out.println("Invocation TopCode");
						method.invoke(block,programme,variables, indexEntrees,associations, algorithme);
						blockInput.put(inputKey, block);
						if(block.getClass() == Variable.class) {
//							variables.add((Variable) block);
						}
						else {
							algorithme.add(block);
						}						
						isInputBlock = false;
						inputKey++;
						
						
					}
					else {
						simpleInput.put(inputKey, entree.getValeur());
						compteurInputs--;
						isInputBlock = false;
						inputKey++;
						
					}
					
				}
		System.out.println("le debut struct " + debutStruct);
		System.out.println("indexEntree boucle : "+indexEntrees);
		System.out.println(programme.get(indexEntrees.getValue()));
		System.out.println("inputKey de la boucle = " + inputKey);
		System.out.println("structKey de la boucle = " + structKey);
		association = associations.get(0);
		while (structKey <= nombreStructures && indexEntrees.getValue()<programme.size()-1) {
			association = associations.get(0);
			System.out.println("Entree Boucle lll");
				System.out.println("MrF");
					System.out.println("MrF");
					
					indexEntrees.add(1);
					entree = programme.get(indexEntrees.getValue());
					System.out.println(entree);
					
					if (entree.getType() == EFamilleEntite.TopCode) {
						System.out.println("Rutabaga");
						System.out.println("le debut struct " + debutStruct);
						if (association.get(Integer.valueOf(entree.getValeur())) == finStruct) {
							structKey++;
						}
						else {
							System.out.println("instanciation sous block");
							if (association.get(Integer.valueOf(entree.getValeur())) == ETypeBlocks.NouveauxBlocs) {
								
								if (indexEntrees.getValue()>= programme.size()-1) {
									System.out.println("Algorithme terminé !!!!");
									return false;
								}						
								indexEntrees.add(1);
							    entree = programme.get(indexEntrees.getValue());
							    association = associations.get(1);
								
							}
							Class<?> cls = Class.forName(association.get(Integer.valueOf(entree.getValeur())).getName());
							Block block = (Block) cls.newInstance();
							System.out.println(block);
							Method method = cls.getMethod("setParent",String.class);
							method.invoke(block, getId());
							System.out.println("le debut struct " + debutStruct);
							traiteSousBloc(programme, variables, indexEntrees,block, associations, algorithme, debutStruct, finStruct, inputKey);
							
							isInputBlock = false;
							structKey++;
							System.out.println(compteurInputs);
						}
						
						
						
					}
					else {
						System.out.println("Inconsistance des données");
						return false;
//						simpleInput.put(inputKey, entree.getValeur());
//						inputKey ++;
//						compteurInputs--;
//						isInputBlock = false;
						
					}
					
				}
				
			
			
			
			
		return true;
		
		
	}
		
	/**
	 * M�thode qui va r�aliser l'instanciation de l'ensemble des sous-blocs d'une structure de contr�le
	 * i.e. traite l'ensemble du programme situ� entre "D�butStruct" et "FinStrucr"
	 * @param programme : Liste(Entite) : le programme reconnu
	 * @param variables : Liste(Variable) : l'ensemble des variables de l'algorithme
	 * @param indexEntrees : l'index courant de la liste programme
	 * @param blocCourant : le blocCourant du programme
	 * @param associations : l'ensemble des associations TopCode :: ETypeBlocks
	 * @param algorithme : l'algorithme � transcrire
	 * @param debutStruct : le bloc de d�but de structure
	 * @param finStruct : le bloc de fin de structure 
	 * @param inputKey : l'index permettant d'enregistrer la position du sous-bloc
	 * @throws ClassNotFoundException : si la classe que l'on veut instancier n'existe pas dans notre code
	 * @throws InstantiationException : erreur lors de l'instanciation
	 * @throws IllegalAccessException : acces illegal
	 * @throws NoSuchMethodException : la m�thode que l'on veut invoquer n'existe pas
	 * @throws SecurityException : erreur de s�curit�
	 * @throws IllegalArgumentException : argument ill�gaux dans la m�thode que l'on veut invoquer
	 * @throws InvocationTargetException : erreur lors de l'invocation de notre m�thode
	 */
		public void traiteSousBloc (LinkedList<Entite> programme, LinkedList<Variable> variables, MutableInt indexEntrees, Block blocCourant, LinkedList<TreeMap<Integer, ETypeBlocks>> associations, LinkedList<Block> algorithme, ETypeBlocks debutStruct, ETypeBlocks finStruct, Integer inputKey) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException{
			TreeMap<Integer, ETypeBlocks> association = associations.get(0);
			System.out.println("Vroooome");
			System.out.println(this);
			System.out.println(debutStruct);
			System.out.println(inputKey);
			System.out.println(blocCourant);
			System.out.println(algorithme);
			if (!(blocCourant instanceof Variable)) {
				blocCourant.ajoutInputsBloc(programme, variables, indexEntrees, associations,algorithme);
			}
			System.out.println("Vroooome vrooooooome");
			System.out.println(this);
			Block blocSuivant = blocCourant.construitBlocSuivant(programme, indexEntrees, associations,variables, algorithme);
			System.out.println(blocSuivant);
			if(blocCourant instanceof Variable) {
				System.out.println("BONJOUR PEPONE ALALAL");
				if (blocSuivant != null) {
					blocSuivant.ajoutInputsBloc(programme, variables, indexEntrees, associations, algorithme);
					blocCourant=blocSuivant;
					System.out.println("zizi");
					System.out.println(blocCourant);
					blocSuivant = blocCourant.construitBlocSuivant(programme, indexEntrees, associations,variables, algorithme);
				}
				
			}
			System.out.println("daronne");
			blockInput.put(inputKey, blocCourant);
			System.out.println(blocCourant);
			System.out.println(blocSuivant);
			algorithme.add(blocCourant);
			blocCourant = blocSuivant;
			System.out.println(blocCourant);
			ListIterator<Entite> li = programme.listIterator(indexEntrees.getValue());
			Entite entree = null;			
			int compteurStruct = 1; 
			
			while (indexEntrees.getValue() < programme.size()-1 && compteurStruct >0) {
				System.out.println(indexEntrees);
				System.out.println("mon compteur struct" + compteurStruct);
				li = programme.listIterator(indexEntrees.getValue());
				entree = programme.get(indexEntrees.getValue());
				
				System.out.println(indexEntrees);
				System.out.println("l'entité 222 de traiteSousBloc : "+entree);
				
				
				
				
				if (association.get(Integer.valueOf(entree.getValeur())) == debutStruct) {
					
				
//					compteurStruct++;
					System.out.println("ma boucle imbriquée !!!!");
					System.out.println(blocCourant);
					System.out.println("indexentreetts " +indexEntrees);
					boolean b = blocCourant.ajoutInputsBloc(programme, variables, indexEntrees, associations,algorithme);
					algorithme.add(blocCourant);
					if (b) {
					System.out.println(" je suis dans bbbb");
					System.out.println(indexEntrees);
					blocSuivant = blocCourant.construitBlocSuivant(programme, indexEntrees, associations, variables, algorithme);
					algorithme.add(blocCourant);
					blocCourant = blocSuivant;
					
					}
					
				}else {
					System.out.println(getDebutStruct());
					System.out.println(finStruct + "oooo");
					if (association.get(Integer.valueOf(entree.getValeur())) == finStruct) {
				         		compteurStruct--;
					}else {
					System.out.println(blocCourant);
					System.out.println("indexentreetts " +indexEntrees);
					boolean b = blocCourant.ajoutInputsBloc(programme, variables, indexEntrees, associations,algorithme);
					algorithme.add(blocCourant);
					if (b) {
					System.out.println(" je suis dans bbbb");
					System.out.println(indexEntrees);
					blocSuivant = blocCourant.construitBlocSuivant(programme, indexEntrees, associations, variables, algorithme);
					algorithme.add(blocCourant);
					blocCourant = blocSuivant;
					
					}
					
				}
				}
				
			}
				
				
				
					
					System.out.println("entree fin de traitement lalala " + entree);
					System.out.println("entree fin de traitement lalala " + indexEntrees);
					
		}
					
					
				
			
				
				
			
			
//		if (li.hasNext()) {
//			indexEntrees++;
//		}
//		if (li.hasNext()) {
//			Entite entree = li.next();
//			if (entree.getType() == EFamilleEntite.TopCode) {
//				Class<?> cls = Class.forName(association.get(Integer.valueOf(entree.getValeur())).getName());
//				Block block = (Block) cls.newInstance();
//				Method method = cls.getMethod("setParent",String.class);
//				method.invoke(block, getId());
//				blockInput.put(inputKey, block);	
//				
//				
//			}
//			else {
//				simpleInput.put(inputKey, entree.getValeur());
//			}
//			inputKey ++;
//		}
//		else {
//		
//		}
//		while (li.hasNext() && isOperator) {
//			Entite entree = li.next();
//			if (entree.getType() == EFamilleEntite.TopCode) {
//				if (!Stream.concat(CategoriesBlocs.operationsElementairesUnaires.stream(), CategoriesBlocs.operationsElementairesBinaires.stream()).collect(Collectors.toList()).contains(association.get(Integer.valueOf(entree.getValeur())))){
//					Class<?> cls = Class.forName(association.get(Integer.valueOf(entree.getValeur())).getName());
//					Block block = (Block) cls.newInstance();
//					Method method = cls.getMethod("setParent",String.class);
//					method.invoke(block, getId());
//					blockInput.put(inputKey, block);	
//					isOperator = false;
//				}				
//				
//			}
//			
//			
//		}
		// TODO Auto-generated method stub
	
//public Block construitBlocSuivant(LinkedList<Entite> programme, Integer indexEntrees, TreeMap<Integer, ETypeBlocks> association) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
//		
////		int iBlocSuivant = indexEntrees;
//		System.out.println("teteet");
//		ListIterator<Entite> li = programme.listIterator(indexEntrees);
//		System.out.println("zzzzz");
//		int compteurStruct = 1;
//		while (li.hasNext()&& compteurStruct>0){
//			Entite entree = li.next();
//			if (entree.getType() == EFamilleEntite.TopCode) {
//				if (association.get(Integer.valueOf(entree.getValeur())) == debutStruct) {
//					compteurStruct++;
//				}
//				if (association.get(Integer.valueOf(entree.getValeur())) == finStruct) {
//					compteurStruct--;
//				}
//			}
//			
//				
//			}
//		if (li.hasNext() && compteurStruct == 0) {
//			Entite entree = li.next();
//			if (entree.getType() == EFamilleEntite.TopCode) {
//				Class<?> cls = Class.forName(association.get(Integer.valueOf(entree.getValeur())).getName());
//				Object block = cls.newInstance();
//				Method method = cls.getMethod("setParent",String.class);
//				method.invoke(block, getId());
//				method = cls.getMethod("getId");
//				String idNext = (String) method.invoke(block);
//				setNext(idNext);
//				return (Block) block;
//			}
//		}
//		else {
//			return null;
//		
//	}
//		return null;
//}
	
	
	
	

}
