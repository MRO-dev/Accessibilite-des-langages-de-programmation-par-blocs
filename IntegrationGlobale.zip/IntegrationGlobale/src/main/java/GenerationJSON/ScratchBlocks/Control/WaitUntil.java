package GenerationJSON.ScratchBlocks.Control;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import GenerationJSON.ScratchBlocks.Block;

public class WaitUntil extends Block {
	    public WaitUntil() {
		super("control_wait_until");
		nombreInputs = 1;
		String[] setInputTitles = new String[] {"CONDITION"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));;
		// TODO Auto-generated constructor stub
	}
	    

		@Override
		public JsonNode genereInput() {
			ObjectMapper mapper = new ObjectMapper();
			JsonNode dataNode = mapper.createObjectNode();
			JsonNode inputNode = mapper.createObjectNode();
			Integer inputsKey = 1;
			Integer indexTitles = 0;
			String inputName = null;
			while (inputsKey <= nombreInputs && indexTitles < inputTitles.size()) {
				inputName = inputTitles.get(indexTitles);
				
				if (blockInput.get(inputsKey)!=null) {
					String json = "{"
							+ "\""+inputName+"\": [\r\n" + 
							"							2,\r\n" + 
							"							\""+blockInput.get(inputsKey).getId()+"\"\r\n" + 
							"						]"
							+ "}";
				try {
					((ObjectNode) dataNode).put(inputName,mapper.readTree(json).get(inputName));
					((ObjectNode) inputNode).put("inputs", dataNode);
					//rootNode.put(Blockinput);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					}
				}
				
				inputsKey++;
				indexTitles++;
				}

		
			return dataNode;
		}

	
	
}
