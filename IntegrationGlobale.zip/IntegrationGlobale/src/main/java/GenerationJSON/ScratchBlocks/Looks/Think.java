package GenerationJSON.ScratchBlocks.Looks;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.TraductionJSON.ICode;

public class Think extends Block implements ICode {

	public Think() {
		super("looks_think");
		nombreInputs = 1;
		String[] setInputTitles = new String[] {"MESSAGE"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "Hello");
		// TODO Auto-generated constructor stub
	}

}
