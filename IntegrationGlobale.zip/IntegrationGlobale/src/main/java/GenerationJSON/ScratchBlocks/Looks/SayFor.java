package GenerationJSON.ScratchBlocks.Looks;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.TraductionJSON.ICode;

public class SayFor extends Block implements ICode {

	public SayFor() {
		super("looks_sayforsecs");
		nombreInputs = 2;
		String[] setInputTitles = new String[] {"MESSAGE", "SECS"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "Hello");
		simpleInput.put(2, "2");
	}



}
