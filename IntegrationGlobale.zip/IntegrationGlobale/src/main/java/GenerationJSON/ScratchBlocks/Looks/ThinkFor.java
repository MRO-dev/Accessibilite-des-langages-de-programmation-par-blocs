package GenerationJSON.ScratchBlocks.Looks;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.TraductionJSON.ICode;

public class ThinkFor extends Block implements ICode{

	public ThinkFor() {
		super("looks_thinkforsecs");
		nombreInputs = 2;
		String[] setInputTitles = new String[] {"MESSAGE", "SECS"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "Hello");
		simpleInput.put(2, "2");
		
	}



}
