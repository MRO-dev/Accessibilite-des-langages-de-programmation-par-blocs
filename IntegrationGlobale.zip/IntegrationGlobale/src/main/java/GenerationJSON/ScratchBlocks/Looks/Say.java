package GenerationJSON.ScratchBlocks.Looks;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.TraductionJSON.ICode;

public class Say extends Block implements ICode {
	

	public Say() {
		super("looks_say");
		nombreInputs = 1;
		String[] setInputTitles = new String[] {"MESSAGE"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "Hello");
		// TODO Auto-generated constructor stub
	}

}
