package GenerationJSON.ScratchBlocks.Operators;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.ScratchBlocks.VariableEntreeBloc;

public class LetterOf extends VariableEntreeBloc{
	
	public LetterOf() {
		super("operator_letter_of");
		nombreInputs = 2;
		String[] setInputTitles = new String[] {"LETTER", "STRING"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "1");
		simpleInput.put(2, "apple");
		
		}

}
