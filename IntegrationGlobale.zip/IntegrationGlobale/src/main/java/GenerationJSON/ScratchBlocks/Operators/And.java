package GenerationJSON.ScratchBlocks.Operators;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.ScratchBlocks.VariableEntreeBloc;

public class And extends VariableEntreeBloc{

	public And() {
		super("operator_and");
		nombreInputs = 2;
		String[] setInputTitles = new String[] {"OPERAND1","OPERAND2"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "");
		simpleInput.put(2, "");
		// TODO Auto-generated constructor stub
	}
	

}
