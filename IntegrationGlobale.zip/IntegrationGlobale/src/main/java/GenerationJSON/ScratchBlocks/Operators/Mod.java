package GenerationJSON.ScratchBlocks.Operators;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.ScratchBlocks.VariableEntreeBloc;

public class Mod extends VariableEntreeBloc{

	public Mod() {
		super("operator_mod");
		nombreInputs = 2;
		String[] setInputTitles = new String[] {"NUM1","NUM2"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "");
		simpleInput.put(2, "");
		// TODO Auto-generated constructor stub
	}
	
	

}
