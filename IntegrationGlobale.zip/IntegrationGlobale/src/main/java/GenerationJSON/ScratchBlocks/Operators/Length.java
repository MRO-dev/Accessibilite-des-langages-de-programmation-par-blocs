package GenerationJSON.ScratchBlocks.Operators;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.ScratchBlocks.VariableEntreeBloc;

public class Length extends VariableEntreeBloc{
	
	public Length() {
		super("operator_length");
		nombreInputs = 1;
		String[] setInputTitles = new String[] {"STRING"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "apple");
		
		
		}

}
