package GenerationJSON.ScratchBlocks.Operators;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.ListIterator;
import java.util.TreeMap;
import java.util.TreeSet;

import GenerationJSON.Outils.InsertionGeneriqueMap;
import GenerationJSON.ScratchBlocks.Musique.ETypeInstrument;
/**
 * Classe impl�mentant l'association codes :: op�rateur math�matique
 * @author Jean-Baptiste
 *
 */
public class CodesMath {
	
	private static final Integer[] SET_VALUES = new Integer[] { 31, 47, 55, 59, 61, 79, 87, 91, 93, 103, 107, 109,
			115, 117};
	private static final TreeSet<Integer> monTreeSet = new TreeSet<Integer>(Arrays.asList(SET_VALUES));
	private static final ArrayList<Integer> codesUtiles = new ArrayList<Integer>(monTreeSet);
	private static InsertionGeneriqueMap<Integer, EMath, TreeMap<Integer,EMath>> igm = new InsertionGeneriqueMap<Integer, EMath, TreeMap<Integer,EMath>>();
 	public static final TreeMap<Integer, EMath> codesMaths;
 	static {
 		 TreeMap<Integer, EMath> auxMap = new TreeMap<Integer,EMath>();
         TreeSet<Integer> monTreeSet = new TreeSet<Integer>(Arrays.asList(SET_VALUES));
 		 ArrayList<Integer> codesUtiles = new ArrayList<Integer>(monTreeSet);
 		 if (codesUtiles.size()!= EMath.values().length) {
 			System.out.println("Inconsistance des entr�es");
 		 }
 		 else {
 			ListIterator<Integer> li = codesUtiles.listIterator();
 			for (EMath valeur : EMath.values()) {
 				igm.put(auxMap,li.next(),valeur);				
 			}
 		}
         codesMaths = auxMap;
     }
 	
 	private CodesMath() {}
	
}
