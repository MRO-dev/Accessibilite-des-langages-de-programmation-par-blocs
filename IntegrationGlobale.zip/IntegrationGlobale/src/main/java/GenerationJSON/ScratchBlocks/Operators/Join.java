package GenerationJSON.ScratchBlocks.Operators;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.ScratchBlocks.VariableEntreeBloc;

public class Join extends VariableEntreeBloc {
	
	public Join() {
	super("operator_join");
	nombreInputs = 2;
	String[] setInputTitles = new String[] {"STRING1", "STRING2"};
	inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
	simpleInput.put(1, "apple");
	simpleInput.put(2, "banana");
	
	}

}
