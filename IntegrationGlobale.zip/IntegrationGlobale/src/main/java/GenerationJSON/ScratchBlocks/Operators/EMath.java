package GenerationJSON.ScratchBlocks.Operators;

/**
 * Enum�ration des diff�rentes op�rations math�matiques 
 * @author Jean-Baptiste
 *
 */
public enum EMath {
	
	ABS("abs"), PLANCHER("floor"), PLAFOND("ceiling"), RACINE("sqrt"), SIN("sin"), COS("cos"), TAN("tan"),
	ASIN("asin"), ACOS("acos") ,ATAN("atan"), LN("ln"), LOG("log"), EXP("e ^"), PUISSANCE("10 ^");
	
	private String name;

	private EMath(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	

}
