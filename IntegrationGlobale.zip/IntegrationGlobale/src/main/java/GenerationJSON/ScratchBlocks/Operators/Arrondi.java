package GenerationJSON.ScratchBlocks.Operators;

import java.util.ArrayList;
import java.util.Arrays;

import GenerationJSON.ScratchBlocks.Block;
import GenerationJSON.ScratchBlocks.VariableEntreeBloc;

public class Arrondi extends VariableEntreeBloc{

	public Arrondi() {
		super("operator_round");
		nombreInputs = 1;
		String[] setInputTitles = new String[] {"NUM1"};
		inputTitles = new ArrayList<String> (Arrays.asList(setInputTitles));
		simpleInput.put(1, "");
		// TODO Auto-generated constructor stub
	}
	
	

}
