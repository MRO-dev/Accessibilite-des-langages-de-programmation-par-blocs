/**
 * Package Comprenant un ensemble de m�thodes et interfaces utiles pour l'ensemble de l'algorithme de g�n�ration de code 
 * @author Jean-Baptiste Marco
 */

package GenerationJSON.Outils;