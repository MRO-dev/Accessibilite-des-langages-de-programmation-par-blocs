package GenerationJSON.Outils;

import java.util.Map;
import java.util.TreeMap;

import GenerationJSON.ScratchBlocks.Motion.ETypePosition;
/**
 * Interface g�n�rique permettant l'insertion g�n�rique d'un couple (Cl�,Valeur) au sein d'une Map
 * @author Jean-Baptiste
 *
 * @param <Cle> : le type de la cl�
 * @param <Valeur> : le type de la valeur
 * @param <Collection> : le type de la collection h�ritant de la classe Map
 */
public interface IPutMap< Cle, Valeur, Collection extends Map<Cle, Valeur>> {
	/**
	 * M�thode d'ajout d'un couple (Cl�,Valeur) au sein d'une Map, en emp�chant l'�crasement si la cl� existe d�j�
	 * @param map : la collection : la collection
	 * @param key : la cl�
	 * @param value : la valeur � ajouter
	 * @return Valeur : la classe de value
	 */
	Valeur put(Collection map,Cle key, Valeur value);

}
