package GenerationJSON.Outils;

/**
 * Enum�ration des deux types d'entit�s entrant en jeu dans le programme reconnu : 
 * - les TopCodes correspondant aux blocs de Scratch 3.0
 * - les Cubarithmes (cubes alg�briques) repr�sentant les donn�es en entr�es (inputs) des blocs de Scratch
 * @author Jean-Baptiste Marco
 *
 */
public enum EFamilleEntite {
	TopCode, Cubarithme
}
