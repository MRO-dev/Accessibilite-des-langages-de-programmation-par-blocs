package GenerationJSON.Outils;

import java.util.Map;
import java.util.TreeMap;

import GenerationJSON.ScratchBlocks.Motion.ETypePosition;

/**
 * Classe impl�mentant l'interface g�n�rique IPutMap qui permet d'ajouter de mani�re g�n�rique un couple (Cl�,Valeur), 
 * tout en emp�chant d'ins�rer une nouvelle valeur pour cl� d�j� existante
 * @author Jean-Baptiste
 *
 * @param <Cle> : le type de la cl�
 * @param <Valeur> : le type de la valeur
 * @param <Collection> : le type de la collection h�ritant de la classe Map
 */
public class InsertionGeneriqueMap<Cle,Valeur, Collection extends Map<Cle,Valeur> > implements IPutMap<Cle, Valeur, Collection> {

	@Override
	public Valeur put(Collection map, Cle key, Valeur value) {
	        if (map.containsKey(key)) {
	         return value;
	        } else {
	          return map.put(key, value);        	  
	          }
	     }
		
	}

	

