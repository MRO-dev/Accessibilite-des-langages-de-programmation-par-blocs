package GenerationJSON.Outils;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Classe repr�sentant les diff�rentes cat�gories de blocs Scratch.
 * Chaque cat�gorie est mod�lis�e sous forme de liste contenant les blocs Scratch qui sont inclus dans celle-ci.
 * @author Jean-Baptiste Marco
 *
 */
public class CategoriesBlocs {
	
	private static final ETypeBlocks[] setOperationsElementairesUnaires = new ETypeBlocks[] {ETypeBlocks.Arrondi, ETypeBlocks.MathOp};
	private static final ETypeBlocks[] setOperationsElementairesBinaires = new ETypeBlocks[] {ETypeBlocks.Addition, ETypeBlocks.Division, ETypeBlocks.Mod, ETypeBlocks.Multiplication, ETypeBlocks.Random, ETypeBlocks.Soustraction};
	private static final ETypeBlocks[] setOperationsElementaires = new ETypeBlocks[] {ETypeBlocks.Arrondi, ETypeBlocks.MathOp,ETypeBlocks.Addition, ETypeBlocks.Division, ETypeBlocks.Mod, ETypeBlocks.Multiplication, ETypeBlocks.Random, ETypeBlocks.Soustraction};
	private static final ETypeBlocks[] setOperationsLogiquesUnaires = new ETypeBlocks[] {ETypeBlocks.Not};
	private static final ETypeBlocks[] setOperationsLogiquesBinaires = new ETypeBlocks[] {ETypeBlocks.Superieur, ETypeBlocks.Inferieur, ETypeBlocks.Egal, ETypeBlocks.And, ETypeBlocks.Or};
	private static final ETypeBlocks[] setOperationsLogiques = new ETypeBlocks[] {ETypeBlocks.Not, ETypeBlocks.Superieur, ETypeBlocks.Inferieur, ETypeBlocks.Egal, ETypeBlocks.And, ETypeBlocks.Or};
	private static final ETypeBlocks[] setOperations = new ETypeBlocks[] {ETypeBlocks.Arrondi, ETypeBlocks.MathOp,ETypeBlocks.Addition, ETypeBlocks.Division, ETypeBlocks.Mod, ETypeBlocks.Multiplication, ETypeBlocks.Random, ETypeBlocks.Soustraction,ETypeBlocks.Not,ETypeBlocks.Superieur, ETypeBlocks.Inferieur, ETypeBlocks.Egal, ETypeBlocks.And, ETypeBlocks.Or, ETypeBlocks.Contains, ETypeBlocks.Join, ETypeBlocks.LetterOf, ETypeBlocks.Length};
	private static final ETypeBlocks[] setInputsBlock = new ETypeBlocks[] {ETypeBlocks.Arrondi, ETypeBlocks.MathOp,ETypeBlocks.Addition, ETypeBlocks.Division, ETypeBlocks.Mod, ETypeBlocks.Multiplication, ETypeBlocks.Random, ETypeBlocks.Soustraction,ETypeBlocks.Not,ETypeBlocks.Superieur, ETypeBlocks.Inferieur, ETypeBlocks.Egal, ETypeBlocks.And, ETypeBlocks.Or, ETypeBlocks.Contains, ETypeBlocks.Join, ETypeBlocks.LetterOf, ETypeBlocks.Length, 
			ETypeBlocks.PositionX, ETypeBlocks.PositionY, ETypeBlocks.Direction, ETypeBlocks.Volume, ETypeBlocks.Variable, ETypeBlocks.Touche, ETypeBlocks.Answer,ETypeBlocks.Timer,ETypeBlocks.Loudness,ETypeBlocks.JoursDepuis2000,ETypeBlocks.Current, ETypeBlocks.Tempo,ETypeBlocks.TouchePressee, ETypeBlocks.SourisPressee, ETypeBlocks.SourisX, ETypeBlocks.SourisY};
	private static final ETypeBlocks[] setParents = new ETypeBlocks[] {ETypeBlocks.WhenFlag,ETypeBlocks.WhenMessage,ETypeBlocks.WhenGreater, ETypeBlocks.WhenClone};
	private static final ETypeBlocks[] setControlAvecInput = new ETypeBlocks[] {ETypeBlocks.RepeatBegin, ETypeBlocks.IfBegin, ETypeBlocks.ForeverBegin, ETypeBlocks.IfElseBegin,ETypeBlocks.RepeatUntilBegin};
	private static final ETypeBlocks[] setVariablesPredefinies = new ETypeBlocks[] {ETypeBlocks.PositionX, ETypeBlocks.PositionY, ETypeBlocks.Direction, ETypeBlocks.Loudness, ETypeBlocks.Volume};
	private static final ETypeBlocks[] setNonInstanciables = new ETypeBlocks[] {ETypeBlocks.RepeatEnd, ETypeBlocks.IfElseEnd, ETypeBlocks.IfElseIfEnd,ETypeBlocks.IfEnd, ETypeBlocks.ForeverEnd, ETypeBlocks.RepeatUntilEnd};
	
	
	public static final ArrayList<ETypeBlocks> operationsElementairesUnaires = new ArrayList<ETypeBlocks>(Arrays.asList(setOperationsElementairesUnaires));
	public static final ArrayList<ETypeBlocks> operationsElementairesBinaires = new ArrayList<ETypeBlocks>(Arrays.asList(setOperationsElementairesBinaires));
	public static final ArrayList<ETypeBlocks> operationsElementaires = new ArrayList<ETypeBlocks>(Arrays.asList(setOperationsElementaires));
	public static final ArrayList<ETypeBlocks> operationsLogiquesUnaires = new ArrayList<ETypeBlocks>(Arrays.asList(setOperationsLogiquesUnaires));
	public static final ArrayList<ETypeBlocks> operationsLogiquesBinaires = new ArrayList<ETypeBlocks>(Arrays.asList(setOperationsLogiquesBinaires));
	public static final ArrayList<ETypeBlocks> operationsLogiques = new ArrayList<ETypeBlocks>(Arrays.asList(setOperationsLogiques));
	public static final ArrayList<ETypeBlocks> operations = new ArrayList<ETypeBlocks> (Arrays.asList(setOperations));
	public static final ArrayList<ETypeBlocks> inputsBlock = new ArrayList<ETypeBlocks> (Arrays.asList(setInputsBlock));
	public static final ArrayList<ETypeBlocks> parents = new ArrayList<ETypeBlocks>(Arrays.asList(setParents));
	public static final ArrayList<ETypeBlocks> controlsAvecInputs = new ArrayList<ETypeBlocks>(Arrays.asList(setControlAvecInput));
	public static final ArrayList<ETypeBlocks> variablesPredefinies = new ArrayList<ETypeBlocks>(Arrays.asList(setVariablesPredefinies));
	public static final ArrayList<ETypeBlocks> nonInstanciables = new ArrayList<ETypeBlocks>(Arrays.asList(setNonInstanciables));
	

}
