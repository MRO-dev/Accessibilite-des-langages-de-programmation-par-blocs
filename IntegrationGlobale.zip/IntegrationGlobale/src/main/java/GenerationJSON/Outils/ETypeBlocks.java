package GenerationJSON.Outils;

import GenerationJSON.ScratchBlocks.Variable;
import GenerationJSON.ScratchBlocks.Control.CreerClone;
import GenerationJSON.ScratchBlocks.Control.Forever;
import GenerationJSON.ScratchBlocks.Control.If;
import GenerationJSON.ScratchBlocks.Control.IfElse;
import GenerationJSON.ScratchBlocks.Control.Repeat;
import GenerationJSON.ScratchBlocks.Control.RepeatUntil;
import GenerationJSON.ScratchBlocks.Control.StopAll;
import GenerationJSON.ScratchBlocks.Control.SupprimeClone;
import GenerationJSON.ScratchBlocks.Control.Wait;
import GenerationJSON.ScratchBlocks.Control.WaitUntil;
import GenerationJSON.ScratchBlocks.Events.Broadcast;
import GenerationJSON.ScratchBlocks.Events.BroadcastWait;
import GenerationJSON.ScratchBlocks.Events.WhenClone;
import GenerationJSON.ScratchBlocks.Events.WhenFlag;
import GenerationJSON.ScratchBlocks.Events.WhenGreater;
import GenerationJSON.ScratchBlocks.Events.WhenMessage;
import GenerationJSON.ScratchBlocks.Looks.Say;
import GenerationJSON.ScratchBlocks.Looks.SayFor;
import GenerationJSON.ScratchBlocks.Looks.Think;
import GenerationJSON.ScratchBlocks.Looks.ThinkFor;
import GenerationJSON.ScratchBlocks.Motion.Bounce;
import GenerationJSON.ScratchBlocks.Motion.ChangeX;
import GenerationJSON.ScratchBlocks.Motion.ChangeY;
import GenerationJSON.ScratchBlocks.Motion.Direction;
import GenerationJSON.ScratchBlocks.Motion.GlideToPos;
import GenerationJSON.ScratchBlocks.Motion.GlideToXY;
import GenerationJSON.ScratchBlocks.Motion.GoToPos;
import GenerationJSON.ScratchBlocks.Motion.GoToXY;
import GenerationJSON.ScratchBlocks.Motion.Moves;
import GenerationJSON.ScratchBlocks.Motion.PointInDirection;
import GenerationJSON.ScratchBlocks.Motion.PositionX;
import GenerationJSON.ScratchBlocks.Motion.PositionY;
import GenerationJSON.ScratchBlocks.Motion.SetX;
import GenerationJSON.ScratchBlocks.Motion.SetY;
import GenerationJSON.ScratchBlocks.Motion.TurnLeft;
import GenerationJSON.ScratchBlocks.Motion.TurnRight;
import GenerationJSON.ScratchBlocks.Musique.ChangeTempo;
import GenerationJSON.ScratchBlocks.Musique.PlayDrum;
import GenerationJSON.ScratchBlocks.Musique.PlayNote;
import GenerationJSON.ScratchBlocks.Musique.RestFor;
import GenerationJSON.ScratchBlocks.Musique.SetInstruTo;
import GenerationJSON.ScratchBlocks.Musique.SetTempo;
import GenerationJSON.ScratchBlocks.Musique.Tempo;
import GenerationJSON.ScratchBlocks.Operators.Addition;
import GenerationJSON.ScratchBlocks.Operators.And;
import GenerationJSON.ScratchBlocks.Operators.Arrondi;
import GenerationJSON.ScratchBlocks.Operators.Contains;
import GenerationJSON.ScratchBlocks.Operators.Division;
import GenerationJSON.ScratchBlocks.Operators.Egal;
import GenerationJSON.ScratchBlocks.Operators.Inferieur;
import GenerationJSON.ScratchBlocks.Operators.Join;
import GenerationJSON.ScratchBlocks.Operators.Length;
import GenerationJSON.ScratchBlocks.Operators.LetterOf;
import GenerationJSON.ScratchBlocks.Operators.MathOp;
import GenerationJSON.ScratchBlocks.Operators.Mod;
import GenerationJSON.ScratchBlocks.Operators.Multiplication;
import GenerationJSON.ScratchBlocks.Operators.Not;
import GenerationJSON.ScratchBlocks.Operators.Or;
import GenerationJSON.ScratchBlocks.Operators.Random;
import GenerationJSON.ScratchBlocks.Operators.Soustraction;
import GenerationJSON.ScratchBlocks.Operators.Superieur;
import GenerationJSON.ScratchBlocks.Sensing.Answer;
import GenerationJSON.ScratchBlocks.Sensing.Ask;
import GenerationJSON.ScratchBlocks.Sensing.Current;
import GenerationJSON.ScratchBlocks.Sensing.JoursDepuis2000;
import GenerationJSON.ScratchBlocks.Sensing.Loudness;
import GenerationJSON.ScratchBlocks.Sensing.ResetTimer;
import GenerationJSON.ScratchBlocks.Sensing.SourisPressee;
import GenerationJSON.ScratchBlocks.Sensing.SourisX;
import GenerationJSON.ScratchBlocks.Sensing.SourisY;
import GenerationJSON.ScratchBlocks.Sensing.Timer;
import GenerationJSON.ScratchBlocks.Sensing.Touche;
import GenerationJSON.ScratchBlocks.Sensing.TouchePressee;
import GenerationJSON.ScratchBlocks.Sounds.ChangeEffect;
import GenerationJSON.ScratchBlocks.Sounds.ChangeVolume;
import GenerationJSON.ScratchBlocks.Sounds.ClearEffects;
import GenerationJSON.ScratchBlocks.Sounds.PlaySoundUntilDone;
import GenerationJSON.ScratchBlocks.Sounds.SetEffect;
import GenerationJSON.ScratchBlocks.Sounds.SetVolume;
import GenerationJSON.ScratchBlocks.Sounds.StartSound;
import GenerationJSON.ScratchBlocks.Sounds.StopSounds;
import GenerationJSON.ScratchBlocks.Sounds.Volume;
import GenerationJSON.ScratchBlocks.Stylo.EffacerTout;
import GenerationJSON.ScratchBlocks.Stylo.Estampiller;
import GenerationJSON.ScratchBlocks.Stylo.ModifierStylo;
import GenerationJSON.ScratchBlocks.Stylo.ModifierTaille;
import GenerationJSON.ScratchBlocks.Stylo.ReleverStylo;
import GenerationJSON.ScratchBlocks.Stylo.SetColor;
import GenerationJSON.ScratchBlocks.Stylo.SetStylo;
import GenerationJSON.ScratchBlocks.Stylo.SetTaille;
import GenerationJSON.ScratchBlocks.Stylo.StyloEcriture;
import GenerationJSON.ScratchBlocks.Variables.ChangeVariable;
import GenerationJSON.ScratchBlocks.Variables.SetVariable;

/**
 * 
 * Mod�lisation de l'ensemble des blocs du langage Scratch.
 * @author Jean-Baptiste Marco
 *
 */
public enum ETypeBlocks {
	/**
	 * Chaque �l�ment de l'�num�ration correspond � un bloc Scratch et poss�de un param�tre name qui est une cha�ne
	 * de cha�ne de caract�res qui r�f�rence la classe Java qui va impl�menter la g�n�ration de code pour le bloc en question. 
	 * Les donn�es formant l'�num�ration poss�dent alors la structure suivante :
	 * NomBlocScratch(Identifiant_de_la_classe_Java_correspondante)
	 */
	
	Moves(Moves.class.getCanonicalName()), TurnLeft(TurnLeft.class.getCanonicalName()), TurnRight(TurnRight.class.getCanonicalName()), GoToXY(GoToXY.class.getCanonicalName()), PointInDirection(PointInDirection.class.getCanonicalName()), 
	ChangeX(ChangeX.class.getCanonicalName()), SetX(SetX.class.getCanonicalName()), ChangeY(ChangeY.class.getCanonicalName()),	SetY(SetY.class.getCanonicalName()), PositionX(PositionX.class.getCanonicalName()),	PositionY(PositionY.class.getCanonicalName()), 
	Direction(Direction.class.getCanonicalName()), SayFor(SayFor.class.getCanonicalName()), Say(Say.class.getCanonicalName()), ThinkFor(ThinkFor.class.getCanonicalName()), Think(Think.class.getCanonicalName()), StartSound(StartSound.class.getCanonicalName()), 
	PlaySoundUntilDone(PlaySoundUntilDone.class.getCanonicalName()), StopSounds(StopSounds.class.getCanonicalName()), ChangeEffect(ChangeEffect.class.getCanonicalName()), SetEffect(SetEffect.class.getCanonicalName()), ClearEffects(ClearEffects.class.getCanonicalName()),
	ChangeVolume(ChangeVolume.class.getCanonicalName()), SetVolume(SetVolume.class.getCanonicalName()), Volume(Volume.class.getCanonicalName()), WhenFlag(WhenFlag.class.getCanonicalName()), WhenGreater(WhenGreater.class.getCanonicalName()), 
	WhenMessage(WhenMessage.class.getCanonicalName()), Broadcast(Broadcast.class.getCanonicalName()), BroadcastWait(BroadcastWait.class.getCanonicalName()), Wait(Wait.class.getCanonicalName()), RepeatBegin(Repeat.class.getCanonicalName()), RepeatEnd("RepeatEnd"), 
	ForeverBegin(Forever.class.getCanonicalName()), ForeverEnd("ForeverEnd"), IfBegin(If.class.getCanonicalName()), IfEnd("IfEnd"), IfElseBegin(IfElse.class.getCanonicalName()), IfElseIfEnd("IfElseIfEnd"), IfElseEnd("IfElseEnd"), WaitUntil(WaitUntil.class.getCanonicalName()), 
	RepeatUntilBegin(RepeatUntil.class.getCanonicalName()), RepeatUntilEnd("RepeatUntilEnd"), StopAll(StopAll.class.getCanonicalName()), Ask(Ask.class.getCanonicalName()), Answer(Answer.class.getCanonicalName()), Loudness(Loudness.class.getCanonicalName()), 
	Addition(Addition.class.getCanonicalName()), Soustraction(Soustraction.class.getCanonicalName()), Multiplication(Multiplication.class.getCanonicalName()), Division(Division.class.getCanonicalName()), Random(Random.class.getCanonicalName()), Superieur(Superieur.class.getCanonicalName()), Inferieur(Inferieur.class.getCanonicalName()), 
	Egal(Egal.class.getCanonicalName()), And(And.class.getCanonicalName()), Or(Or.class.getCanonicalName()), Not(Not.class.getCanonicalName()), Mod(Mod.class.getCanonicalName()), Arrondi(Arrondi.class.getCanonicalName()), MathOp(MathOp.class.getCanonicalName()), 
	Variable(Variable.class.getCanonicalName()), SetVariable(SetVariable.class.getCanonicalName()), ChangeVariable(ChangeVariable.class.getCanonicalName()), GoToPos(GoToPos.class.getCanonicalName()), GlideToPos(GlideToPos.class.getCanonicalName()), GlideToXY(GlideToXY.class.getCanonicalName()), 
	Bounce(Bounce.class.getCanonicalName()), ChangeTempo (ChangeTempo.class.getCanonicalName()), PlayDrum(PlayDrum.class.getCanonicalName()), PlayNote(PlayNote.class.getCanonicalName()), 
	RestFor(RestFor.class.getCanonicalName()), SetInstruTo(SetInstruTo.class.getCanonicalName()), SetTempo(SetTempo.class.getCanonicalName()), Tempo(Tempo.class.getCanonicalName()), JoursDepuis2000(JoursDepuis2000.class.getCanonicalName()), ResetTimer(ResetTimer.class.getCanonicalName()), Timer(Timer.class.getCanonicalName()),
	CreerClone(CreerClone.class.getCanonicalName()), SupprimeClone(SupprimeClone.class.getCanonicalName()), WhenClone(WhenClone.class.getCanonicalName()), Join(Join.class.getCanonicalName()), Length(Length.class.getCanonicalName()), LetterOf(LetterOf.class.getCanonicalName()), Contains(Contains.class.getCanonicalName()), 
	Touche(Touche.class.getCanonicalName()), Current(Current.class.getCanonicalName()),TouchePressee(TouchePressee.class.getCanonicalName()), SourisPressee(SourisPressee.class.getCanonicalName()), SourisX(SourisX.class.getCanonicalName()), SourisY(SourisY.class.getCanonicalName()), EffacerTout(EffacerTout.class.getCanonicalName()), Estampiller(Estampiller.class.getCanonicalName()), ModifierStylo(ModifierStylo.class.getCanonicalName()), RelerverStylo(ReleverStylo.class.getCanonicalName()), SetColor(SetColor.class.getCanonicalName()), StyloEcriture(StyloEcriture.class.getCanonicalName()), NouveauxBlocs("NouveauxBlocs"), Parasite("Parasite"), 
	SetStylo(SetStylo.class.getCanonicalName()), ModifierTaille(ModifierTaille.class.getCanonicalName()), SetTaille(SetTaille.class.getCanonicalName());
	

	private String name;
	
	ETypeBlocks(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

}
