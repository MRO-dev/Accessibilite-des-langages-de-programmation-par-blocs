package GenerationJSON.Outils;

/**
 * Classe Java mod�lisant une entit� reconnue par l'algorithme de reconnaissance d'image
 * @author Jean-Baptiste Marco
 * 
 *
 */
public class Entite {
	
	private EFamilleEntite type;
	private String valeur;
	
	/**
	 * Constructeur 
	 * @param type EFamilleEntite, le type d'entit� : TopCode ou Cubarithme
	 * @param valeur String, la valeur contenue par l'entit� sous forme de cha�ne de caract�res pour permettre de stocker des
	 * donn�es de fa�on g�n�rique (valeur num�rique pour les TopCodes, carat�res alphanum�riques pour les Cubarithmes). 
	 */
	public Entite(EFamilleEntite type, String valeur) {
		this.type = type;
		this.valeur = valeur;
	}
	
	public EFamilleEntite getType() {
		return type;
	}
	
	public String getValeur() {
		return valeur;
	}

	@Override
	public String toString() {
		return "Entite [type=" + type + ", valeur=" + valeur + "]";
	}
	
	
	
	
}
