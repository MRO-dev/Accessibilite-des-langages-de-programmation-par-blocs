package GenerationJSON.Outils;

import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.TreeMap;

import topcodes.TopCode;

/**
 * Classe contenant les m�thodes d'ajout d'entit� � un algorithme. Un programme Scratch est mod�lis� informatiquement par
 * une liste d'entit�s tri�e selon l'ordre chronologique d'un algorithme Scratch. 
 * @author Jean-Baptiste
 *
 */
public class EntreesProgramme {
	
	private static final LinkedList<TreeMap<Integer, ETypeBlocks>> association = CodesSemantique.association;

	 
	 /**
	  * M�thode d'ajout d'un cubarithme	
	  * @param programme LinkedList, la liste stockant l'ensemble des entit�s du programme dans l'ordre chronologique
	  * @param valeur, la valeur num�rique � stocker au sein de l'entit� cubarithme
	  */
	 public static void ajoutCubarithme (LinkedList<Entite> programme, float valeur) {
		 Entite entite = new Entite(EFamilleEntite.Cubarithme, String.valueOf(valeur));
		 programme.add(entite);
	 }
	 
	 /**
	  * M�thode d'ajout d'un cubarithme	
	  * @param programme LinkedList, la liste stockant l'ensemble des entit�s du programme dans l'ordre chronologique
	  * @param valeur, la valeur sous forme de cha�ne de caract�res � stocker au sein de l'entit� cubarithme
	  */
	 public static void ajoutCubarithme (LinkedList<Entite> programme, String valeur) {
		 Entite entite = new Entite(EFamilleEntite.Cubarithme, valeur);
		 programme.add(entite);
	 }

	 /**
	  * M�thode d'ajout d'un TopCode	
	  * @param programme LinkedList, la liste stockant l'ensemble des entit�s du programme dans l'ordre chronologique
	  * @param bloc, pour ajouter un bloc directement � notre programme sans se soucier du TopCode correspondant
	  */ 
	public static void ajoutTopCode(LinkedList<Entite> programme, ETypeBlocks bloc) {
		Integer code = getCode(association, bloc);		
		Entite entite = new Entite(EFamilleEntite.TopCode, String.valueOf(code));
		programme.add(entite);
		
	}
	
	/**
	  * M�thode d'ajout d'un TopCode	
	  * @param programme LinkedList, la liste stockant l'ensemble des entit�s du programme dans l'ordre chronologique
	  * @param code, l'objet TopCode dont on va ajouter le code � notre programme
	  */ 
	public static void ajoutTopCode(LinkedList<Entite> programme, TopCode code) {
		Entite entite = new Entite(EFamilleEntite.TopCode, String.valueOf(code.getCode()));
		programme.add(entite);
	}
	
	/**
	 * M�thode permettant d'obtenir la cl� connaissant la valeur au sein d'une TreeMap 
	 * @param map TreeMap
	 * @param value ETypeBlocks, la valeur dont on veut conna�tre la cl�
	 * @return Integer, la cl� correspondant � value
	 */
	private static Integer getKeyByValue(TreeMap<Integer, ETypeBlocks> map, ETypeBlocks value) {
	    for (Entry<Integer, ETypeBlocks> entry : map.entrySet()) {
	        if (Objects.equals(value, entry.getValue())) {
	            return entry.getKey();
	        }
	    }
	    return null;
	}
	
	/**
	 * M�thode permettant d'associer le code correspondant � un Bloc
	 * @param asso : liste de repr�sentant l'ensemble des associations TopCodes<->ETypeBlocks
	 * @param value : le bloc dont on veut conna�tre le TopCode associ�
	 * @return Integer : le TopCode associ� au bloc value.
	 */
	private static Integer getCode(LinkedList<TreeMap<Integer, ETypeBlocks>> asso, ETypeBlocks value) {
		if (asso.size() == 0) {
			System.out.println("Inconsistance");
			return null;
		}else {
			for (TreeMap<Integer, ETypeBlocks> map : asso) {
				Integer key = getKeyByValue(map, value);
				if (key != null) {
					return key;
				}
			}
		}
		return null;
	    
	}
}

