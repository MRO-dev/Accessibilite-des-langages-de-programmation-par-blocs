package GenerationJSON.Outils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.TreeMap;
import java.util.TreeSet;

import GenerationJSON.ScratchBlocks.Motion.ETypePosition;

/**
 * Classe mod�lisant l'association entre les TopCodes et les blocs Scratch. 
 * Cette classe contient un TreeMap permettant d'identifier de mani�re unique chaque bloc de Scratch via les diff�rents TopCodes.  
 * @author Jean-Baptiste Marco
 *
 */
public final class CodesSemantique {
	
	
	public static final Integer[] SET_VALUES = new Integer[] { 31, 47, 55, 59, 61, 79, 87, 91, 93, 103, 107, 109,
			115, 117, 121, 143, 151, 155, 157, 167, 171, 173, 179, 181, 185, 199, 203, 205, 211, 213, 217, 227, 229, 233, 241, 271, 279, 283, 285, 295, 
			299, 301, 307, 309, 313, 327, 331, 333, 339, 341, 345, 355, 357, 361, 369, 391, 395, 397, 403, 405, 409, 419, 421, 425, 433, 453, 457, 465, 551, 555, 557, 563,
			565, 569, 583, 587, 589, 595, 597, 601, 611, 613, 617, 651, 653, 659, 661,665, 675, 677, 681, 713, 793, 805, 809, 841, 1171, 1173, 1189};
	public static final Integer[] SET_NEW_VALUES =new Integer[] {31, 47, 55};
	private static final TreeSet<Integer> monTreeSet = new TreeSet<Integer>(Arrays.asList(SET_VALUES));
	private static final TreeSet<Integer> monNouveauTreeSet = new TreeSet<Integer>(Arrays.asList(SET_NEW_VALUES));
	private static final ArrayList<Integer> codesUtiles = new ArrayList<Integer>(monTreeSet);
	private static final ArrayList<Integer> codesNouveauxBlocs = new ArrayList<Integer>(monNouveauTreeSet);
	private static InsertionGeneriqueMap<Integer, ETypeBlocks, TreeMap<Integer,ETypeBlocks>> igm = new InsertionGeneriqueMap<Integer, ETypeBlocks, TreeMap<Integer,ETypeBlocks>>();
 	public static final LinkedList<TreeMap<Integer, ETypeBlocks>> association;
 	static {
 		 association = new LinkedList<TreeMap<Integer, ETypeBlocks>>();
 		 TreeMap<Integer, ETypeBlocks> auxMap = new TreeMap<Integer,ETypeBlocks>();   
 		 TreeMap<Integer, ETypeBlocks> newAuxMap = new TreeMap<Integer,ETypeBlocks>();   
 		 if ((codesUtiles.size() + codesNouveauxBlocs.size())!= ETypeBlocks.values().length) {
 			System.out.println("Inconsistance des entr�es");
 		 }
 		 else {
 			ListIterator<Integer> li = codesUtiles.listIterator();
 			ListIterator<Integer> liNew = codesNouveauxBlocs.listIterator();
 			for (ETypeBlocks valeur : ETypeBlocks.values()) {
 				if(li.hasNext()) {
 					igm.put(auxMap,li.next(),valeur);
 				}else {
 					igm.put(newAuxMap,liNew.next(),valeur);
 				}
 								
 			}
 		}
 		association.add(auxMap);
        association.add(newAuxMap);
     }
	
		

	
	

	
	
	

}
