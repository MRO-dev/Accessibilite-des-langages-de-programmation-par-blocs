/**
 * Package racine du projet effectuant la transcription d'un algorithme reconnu par la reconnaissance optique en un fichier au 
 * format textuel JSON reprenant la structure d'un projet Scratch
 * @author Jean-Baptiste Marco
 */

package GenerationJSON;